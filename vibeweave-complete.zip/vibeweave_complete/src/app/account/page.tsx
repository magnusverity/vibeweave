"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Nav from "@/components/Nav";

export default function AccountPage() {
  const [mode, setMode] = useState<"login" | "signup">("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [account, setAccount] = useState<any>(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const r = await fetch("/api/account/me");
    const d = await r.json();
    if (d.success) setAccount(d.account);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const submit = async () => {
    setMessage("");
    const endpoint = mode === "signup" ? "/api/account/signup" : "/api/account/login";
    const body = mode === "signup" ? { name, email, password } : { email, password };
    const r = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json();
    if (!d.success) return setMessage(d.error || "Something went wrong");
    setAccount(d.account);
    setMessage(mode === "signup" ? "Account created." : "Welcome back.");
  };

  const logout = async () => { await fetch("/api/account/logout", { method: "POST" }); setAccount(null); };

  if (loading) return <div className="min-h-screen bg-[#FAF8F5] flex items-center justify-center">Loading...</div>;

  return <div className="min-h-screen bg-[#FAF8F5]"><Nav /><main className="max-w-xl mx-auto px-6 pt-32 pb-20">
    {account ? <>
      <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono">My Account</span>
      <h1 className="font-editorial font-bold text-5xl text-[#0D0D0D] mt-3 mb-8">Welcome, {account.name}.</h1>
      <div className="border border-[#E0DDD8] p-6 mb-6"><p className="text-sm">{account.email}</p><p className="text-sm text-[#7A7672] mt-2">Token balance: <strong>{account.tokenBalance}</strong></p></div>
      <div className="flex gap-3"><Link href="/studio" className="bg-[#0D0D0D] text-[#FAF8F5] px-6 py-3 text-sm">Create an order →</Link><button onClick={logout} className="border border-[#E0DDD8] px-6 py-3 text-sm">Log out</button></div>
    </> : <>
      <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono">VibeWeave Account</span>
      <h1 className="font-editorial font-bold text-5xl text-[#0D0D0D] mt-3 mb-8">{mode === "signup" ? "Set up your account." : "Welcome back."}</h1>
      <div className="space-y-4">
        {mode === "signup" && <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" className="w-full border border-[#E0DDD8] p-4 bg-transparent" />}
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" type="email" className="w-full border border-[#E0DDD8] p-4 bg-transparent" />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password (8+ characters)" type="password" className="w-full border border-[#E0DDD8] p-4 bg-transparent" />
        <button onClick={submit} className="w-full bg-[#0D0D0D] text-[#FAF8F5] py-4 text-sm font-bold">{mode === "signup" ? "CREATE ACCOUNT" : "LOG IN"}</button>
      </div>
      {message && <p className="text-sm mt-4">{message}</p>}
      <button onClick={()=>{setMode(mode === "signup" ? "login" : "signup"); setMessage("");}} className="text-sm text-[#7A7672] mt-6 underline">{mode === "signup" ? "Already have an account? Log in" : "Need an account? Sign up"}</button>
    </>}
  </main></div>;
}
