import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { accounts, tokenTransactions } from "@/db/schema";
import { isAdminRequest, jsonError } from "@/lib/api";
import { newId } from "@/lib/auth";
import { eq, sql } from "drizzle-orm";

export async function POST(req: NextRequest) {
  if (!isAdminRequest(req)) return jsonError("Unauthorized", 401);
  try {
    const body = await req.json();
    const accountId = typeof body.accountId === "string" ? body.accountId : "";
    const amount = Number(body.amount);
    const reason = typeof body.reason === "string" ? body.reason.trim().slice(0, 200) : "Admin adjustment";
    if (!accountId || !Number.isInteger(amount) || amount === 0) return jsonError("accountId and a non-zero integer amount are required");
    const [account] = await db.select({ id: accounts.id }).from(accounts).where(eq(accounts.id, accountId)).limit(1);
    if (!account) return jsonError("Account not found", 404);
    if (amount < 0) {
      const [current] = await db.select({ balance: accounts.tokenBalance }).from(accounts).where(eq(accounts.id, accountId));
      if (!current || current.balance + amount < 0) return jsonError("Insufficient token balance", 409);
    }
    await db.transaction(async (tx) => {
      await tx.update(accounts).set({ tokenBalance: sql`${accounts.tokenBalance} + ${amount}`, updatedAt: new Date() }).where(eq(accounts.id, accountId));
      await tx.insert(tokenTransactions).values({ id: newId("tok"), accountId, amount, type: amount > 0 ? "credit" : "debit", reason });
    });
    const [updated] = await db.select({ id: accounts.id, tokenBalance: accounts.tokenBalance }).from(accounts).where(eq(accounts.id, accountId));
    return NextResponse.json({ success: true, account: updated });
  } catch (error) { console.error("Token adjustment error:", error); return jsonError("Failed to adjust tokens", 500); }
}
