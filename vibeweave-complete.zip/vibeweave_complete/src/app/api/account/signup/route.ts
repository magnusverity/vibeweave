import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { accounts } from "@/db/schema";
import { createSession, hashPassword, newId, normalizeEmail } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? normalizeEmail(body.email) : "";
    const password = typeof body.password === "string" ? body.password : "";
    const phone = typeof body.phone === "string" ? body.phone.trim() : null;
    if (name.length < 2 || name.length > 100) return NextResponse.json({ success: false, error: "Valid name is required" }, { status: 400 });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ success: false, error: "Valid email is required" }, { status: 400 });
    if (password.length < 8 || password.length > 200) return NextResponse.json({ success: false, error: "Password must be 8-200 characters" }, { status: 400 });
    const existing = await db.select({ id: accounts.id }).from(accounts).where(eq(accounts.email, email)).limit(1);
    if (existing[0]) return NextResponse.json({ success: false, error: "An account with this email already exists" }, { status: 409 });
    const id = newId("acct");
    const [account] = await db.insert(accounts).values({ id, email, passwordHash: hashPassword(password), name, phone }).returning({ id: accounts.id, email: accounts.email, name: accounts.name, phone: accounts.phone, tokenBalance: accounts.tokenBalance });
    await createSession(id);
    return NextResponse.json({ success: true, account }, { status: 201 });
  } catch (error) {
    console.error("Signup error:", error);
    return NextResponse.json({ success: false, error: "Failed to create account" }, { status: 500 });
  }
}
