import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { accounts } from "@/db/schema";
import { getCurrentAccount } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET() {
  const account = await getCurrentAccount();
  if (!account) return NextResponse.json({ success: false, error: "Not authenticated" }, { status: 401 });
  return NextResponse.json({ success: true, account: { id: account.id, email: account.email, name: account.name, phone: account.phone, address: account.address, city: account.city, pin: account.pin, tokenBalance: account.tokenBalance } });
}

export async function PATCH(req: NextRequest) {
  const account = await getCurrentAccount();
  if (!account) return NextResponse.json({ success: false, error: "Not authenticated" }, { status: 401 });
  try {
    const body = await req.json();
    const updates: Record<string, unknown> = { updatedAt: new Date() };
    for (const key of ["name", "phone", "address", "city", "pin"]) {
      if (body[key] !== undefined) {
        if (body[key] !== null && typeof body[key] !== "string") return NextResponse.json({ success: false, error: `${key} must be a string` }, { status: 400 });
        updates[key] = typeof body[key] === "string" ? body[key].trim().slice(0, 200) : null;
      }
    }
    if (Object.keys(updates).length === 1) return NextResponse.json({ success: false, error: "No supported fields supplied" }, { status: 400 });
    const [updated] = await db.update(accounts).set(updates).where(eq(accounts.id, account.id)).returning({ id: accounts.id, email: accounts.email, name: accounts.name, phone: accounts.phone, address: accounts.address, city: accounts.city, pin: accounts.pin, tokenBalance: accounts.tokenBalance });
    return NextResponse.json({ success: true, account: updated });
  } catch (error) { console.error("Account update error:", error); return NextResponse.json({ success: false, error: "Failed to update account" }, { status: 500 }); }
}
