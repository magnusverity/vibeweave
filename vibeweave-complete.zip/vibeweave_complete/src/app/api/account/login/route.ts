import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { accounts } from "@/db/schema";
import { createSession, normalizeEmail, verifyPassword } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email = typeof body.email === "string" ? normalizeEmail(body.email) : "";
    const password = typeof body.password === "string" ? body.password : "";
    const [account] = await db.select().from(accounts).where(eq(accounts.email, email)).limit(1);
    if (!account || !verifyPassword(password, account.passwordHash)) return NextResponse.json({ success: false, error: "Invalid email or password" }, { status: 401 });
    await createSession(account.id);
    return NextResponse.json({ success: true, account: { id: account.id, email: account.email, name: account.name, phone: account.phone, address: account.address, city: account.city, pin: account.pin, tokenBalance: account.tokenBalance } });
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json({ success: false, error: "Failed to log in" }, { status: 500 });
  }
}
