import { NextResponse } from "next/server";
import { db } from "@/db";
import { tokenTransactions } from "@/db/schema";
import { getCurrentAccount } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const account = await getCurrentAccount();
  if (!account) return NextResponse.json({ success: false, error: "Not authenticated" }, { status: 401 });
  const transactions = await db.select().from(tokenTransactions).where(eq(tokenTransactions.accountId, account.id)).orderBy(desc(tokenTransactions.createdAt)).limit(100);
  return NextResponse.json({ success: true, balance: account.tokenBalance, transactions });
}
