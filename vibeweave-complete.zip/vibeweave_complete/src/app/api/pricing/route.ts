import { NextRequest, NextResponse } from "next/server";
import { calculateTotal, getPrintSizeById, getProductById } from "@/lib/constants";
import { getDeliveryOption } from "@/lib/delivery";
import { OrderValidationError } from "@/lib/orderValidation";
import { jsonError } from "@/lib/api";

export async function GET(req: NextRequest) {
  try {
    const p = new URL(req.url).searchParams;
    const garment = p.get("garment") ?? "";
    const printSize = p.get("printSize") ?? "";
    const clothingQty = Number(p.get("clothingQty") ?? 1);
    const designQty = Number(p.get("designQty") ?? 1);
    const deliveryMethod = p.get("deliveryMethod") ?? "pickup";
    const deliverySpeed = p.get("deliverySpeed") ?? "normal";
    if (!getProductById(garment)) throw new OrderValidationError("Invalid garment");
    if (!getPrintSizeById(printSize)) throw new OrderValidationError("Invalid printSize");
    if (!Number.isInteger(clothingQty) || clothingQty < 1 || clothingQty > 100) throw new OrderValidationError("Invalid clothingQty");
    if (!Number.isInteger(designQty) || designQty < 1 || designQty > 100) throw new OrderValidationError("Invalid designQty");
    if (deliveryMethod !== "delivery" && deliveryMethod !== "pickup") throw new OrderValidationError("Invalid deliveryMethod");
    const delivery = deliveryMethod === "delivery" ? getDeliveryOption(deliverySpeed) : null;
    if (deliveryMethod === "delivery" && !delivery) throw new OrderValidationError("Invalid deliverySpeed");
    const baseAmount = calculateTotal(garment, printSize, clothingQty, designQty);
    const deliveryFee = delivery?.fee ?? 0;
    return NextResponse.json({ success: true, baseAmount, deliveryFee, deliveryEtaDays: delivery?.etaDays ?? null, amount: baseAmount + deliveryFee });
  } catch (err) {
    if (err instanceof OrderValidationError) return jsonError(err.message);
    return jsonError("Failed to calculate price", 500);
  }
}
