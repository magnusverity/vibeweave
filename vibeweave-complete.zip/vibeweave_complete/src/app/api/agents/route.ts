import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { agents } from "@/db/schema";
import { isAdminRequest, jsonError } from "@/lib/api";
import { eq } from "drizzle-orm";

export async function GET() {
  const result = await db.select().from(agents).where(eq(agents.active, 1));
  return NextResponse.json({ success: true, agents: result });
}

export async function POST(req: NextRequest) {
  if (!isAdminRequest(req)) return jsonError("Unauthorized", 401);
  try {
    const body = await req.json();
    const id = typeof body.id === "string" ? body.id.trim().toLowerCase() : "";
    const name = typeof body.name === "string" ? body.name.trim() : "";
    if (!/^[a-z0-9_-]{2,40}$/.test(id) || name.length < 2) return jsonError("Valid id and name are required");
    const [agent] = await db.insert(agents).values({ id, name, phone: body.phone ?? null, address: body.address ?? null, availability: body.availability ?? null }).returning();
    return NextResponse.json({ success: true, agent }, { status: 201 });
  } catch (error) { console.error("Agent create error:", error); return jsonError("Failed to create agent", 500); }
}
