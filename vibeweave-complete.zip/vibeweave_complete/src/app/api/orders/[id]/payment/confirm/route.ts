import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentAccount } from "@/lib/auth";
import { isAdminRequest, jsonError } from "@/lib/api";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return jsonError("Order not found", 404);
    const account = await getCurrentAccount();
    if (order.accountId && (!account || (account.id !== order.accountId && !isAdminRequest(req)))) return jsonError("Unauthorized", 401);
    const body = await req.json();
    const transactionReference = typeof body.transactionReference === "string" ? body.transactionReference.trim().slice(0, 120) : "";
    const paymentProofUrl = typeof body.paymentProofUrl === "string" ? body.paymentProofUrl.trim() : null;
    if (!transactionReference) return jsonError("UPI transaction reference is required");
    if (paymentProofUrl && !/^\/(?:uploads)\/[A-Za-z0-9._-]+$/.test(paymentProofUrl)) return jsonError("Invalid paymentProofUrl");
    const [updated] = await db.update(orders).set({ paymentStatus: "pending", paymentProvider: "manual_upi", paymentReference: transactionReference, paymentProofUrl, updatedAt: new Date() }).where(eq(orders.id, id)).returning();
    return NextResponse.json({ success: true, order: updated, message: "Payment submitted for manual verification." });
  } catch (error) { console.error("Payment confirmation error:", error); return NextResponse.json({ success: false, error: "Failed to submit payment" }, { status: 500 }); }
}
