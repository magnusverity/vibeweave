import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createPaymentIntent } from "@/lib/payment";
import { isAdminRequest, jsonError } from "@/lib/api";
import { getCurrentAccount } from "@/lib/auth";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const account = await getCurrentAccount();
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return jsonError("Order not found", 404);
    if (order.accountId && (!account || (account.id !== order.accountId && !isAdminRequest(_req)))) return jsonError("Unauthorized", 401);
    if (order.paymentStatus === "paid") return jsonError("Order is already paid", 409);
    if (order.status === "cancelled") return jsonError("Cancelled orders cannot be paid", 409);

    const intent = await createPaymentIntent(order.id, order.totalAmount);
    const [updated] = await db.update(orders).set({
      paymentProvider: intent.provider,
      paymentReference: intent.reference,
      updatedAt: new Date(),
    }).where(eq(orders.id, order.id)).returning();

    return NextResponse.json({
      success: true,
      payment: { provider: intent.provider, reference: intent.reference, checkoutUrl: intent.checkoutUrl, payment: intent.payment },
      order: updated,
      message: "Manual UPI payment is ready. Pay using the QR/details, then submit the transaction reference for verification.",
    });
  } catch (error) {
    console.error("Payment intent error:", error);
    return NextResponse.json({ success: false, error: "Failed to initialize payment" }, { status: 500 });
  }
}
