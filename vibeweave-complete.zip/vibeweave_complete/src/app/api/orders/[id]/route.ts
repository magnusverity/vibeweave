import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { OrderValidationError, validatePaymentStatus, validateStatus } from "@/lib/orderValidation";
import { isAdminRequest, jsonError } from "@/lib/api";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!isAdminRequest(req)) return jsonError("Unauthorized", 401);
  const { id } = await params;
  try {
    const body = await req.json();
    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (body.status !== undefined) updates.status = validateStatus(body.status);
    if (body.paymentStatus !== undefined) updates.paymentStatus = validatePaymentStatus(body.paymentStatus);
    if (body.paymentProvider !== undefined) updates.paymentProvider = typeof body.paymentProvider === "string" ? body.paymentProvider.slice(0, 100) : null;
    if (body.paymentReference !== undefined) updates.paymentReference = typeof body.paymentReference === "string" ? body.paymentReference.slice(0, 200) : null;
    if (Object.keys(updates).length === 1) return jsonError("No supported fields supplied");

    const [order] = await db.update(orders).set(updates).where(eq(orders.id, id)).returning();
    if (!order) return jsonError("Order not found", 404);
    return NextResponse.json({ success: true, order });
  } catch (err) {
    if (err instanceof SyntaxError) return jsonError("Invalid JSON body");
    if (err instanceof OrderValidationError) return jsonError(err.message);
    console.error("Order update error:", err);
    return jsonError("Failed to update order", 500);
  }
}
