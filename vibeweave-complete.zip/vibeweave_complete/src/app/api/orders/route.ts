import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { OrderValidationError, validateCreateOrder } from "@/lib/orderValidation";
import { isAdminRequest, jsonError } from "@/lib/api";
import { getCurrentAccount } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const input = validateCreateOrder(body);
    const account = await getCurrentAccount();
    const id = `VW-${uuidv4().replaceAll("-", "").slice(0, 16).toUpperCase()}`;
    const [order] = await db.insert(orders).values({ ...input, id, accountId: account?.id ?? null, status: "payment_pending", paymentStatus: "pending" }).returning();
    return NextResponse.json({ success: true, order }, { status: 201 });
  } catch (err) {
    if (err instanceof SyntaxError) return jsonError("Invalid JSON body");
    if (err instanceof OrderValidationError) return jsonError(err.message);
    console.error("Order creation error:", err);
    return jsonError("Failed to create order", 500);
  }
}

export async function GET(req: NextRequest) {
  try {
    const params = new URL(req.url).searchParams;
    const id = params.get("id")?.trim();
    if (id) {
      const [order] = await db.select().from(orders).where(eq(orders.id, id));
      if (!order) return jsonError("Order not found", 404);
      const account = await getCurrentAccount();
      if (order.accountId && (!account || (account.id !== order.accountId && !isAdminRequest(req)))) return jsonError("Unauthorized", 401);
      return NextResponse.json({ success: true, order });
    }
    if (!isAdminRequest(req)) return jsonError("An order id is required", 400);
    const limit = Math.min(Math.max(Number(params.get("limit") ?? 50), 1), 100);
    const result = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit);
    return NextResponse.json({ success: true, orders: result });
  } catch (err) {
    console.error("Order fetch error:", err);
    return jsonError("Failed to fetch orders", 500);
  }
}
