import { NextResponse } from "next/server";
import { getDeliveryOptions } from "@/lib/delivery";
export async function GET() { return NextResponse.json({ success: true, options: getDeliveryOptions() }); }
