"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import Nav from "@/components/Nav";
import { useOrderStore } from "@/store/orderStore";

interface OrderData {
  id: string;
  garment: string;
  color: string;
  size: string;
  printSize: string;
  clothingQty: number;
  designQty: number;
  deliveryMethod: string;
  pickupPerson?: string;
  customerName?: string;
  customerCity?: string;
  totalAmount: number;
  createdAt: string;
  paymentStatus: string;
  deliverySpeed?: string | null;
  deliveryFee?: number;
}

function ConfirmationContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get("id");
  const [order, setOrder] = useState<OrderData | null>(null);
  const [loading, setLoading] = useState(true);
  const [payment, setPayment] = useState<{ provider: string; reference: string; payment: { name: string | null; upiId: string | null; phone: string | null; qrUrl: string } } | null>(null);
  const [transactionReference, setTransactionReference] = useState("");
  const [paymentMessage, setPaymentMessage] = useState("");
  const [paymentSubmitting, setPaymentSubmitting] = useState(false);
  const resetOrder = useOrderStore((s) => s.resetOrder);

  useEffect(() => {
    if (orderId) {
      fetch(`/api/orders?id=${orderId}`)
        .then((r) => r.json())
        .then(async (data) => {
          if (data.success) {
            setOrder(data.order);
            const paymentRes = await fetch(`/api/orders/${orderId}/payment`, { method: "POST" });
            const paymentData = await paymentRes.json();
            if (paymentData.success) setPayment(paymentData.payment);
          }
        })
        .finally(() => setLoading(false));
    }
    // Reset the store after confirmation
    const t = setTimeout(() => resetOrder(), 2000);
    return () => clearTimeout(t);
  }, [orderId, resetOrder]);

  const submitPayment = async () => {
    if (!orderId || !transactionReference.trim()) return;
    setPaymentSubmitting(true);
    try {
      const res = await fetch(`/api/orders/${orderId}/payment/confirm`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ transactionReference }) });
      const data = await res.json();
      setPaymentMessage(data.success ? "Payment submitted. The VibeWeave team will verify it." : (data.error || "Could not submit payment."));
      if (data.success) setOrder(data.order);
    } finally { setPaymentSubmitting(false); }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAF8F5] flex items-center justify-center">
        <div className="font-mono text-[#7A7672] text-sm tracking-widest">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF8F5]">
      <Nav />
      <div className="max-w-2xl mx-auto px-6 md:px-12 pt-32 pb-20">
        {/* Success animation */}
        <div className="flex items-center justify-center mb-10">
          <div className="w-20 h-20 bg-[#C8FF00] rounded-full flex items-center justify-center animate-[pop_0.5s_cubic-bezier(0.175,0.885,0.32,1.275)_forwards]">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
              <path
                d="M8 18L15 25L28 11"
                stroke="#0D0D0D"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="animate-[draw_0.5s_ease_0.3s_forwards]"
                style={{ strokeDasharray: 40, strokeDashoffset: 40 }}
              />
            </svg>
          </div>
        </div>

        <div className="text-center mb-12">
          <span className="text-[11px] tracking-[0.25em] uppercase text-[#7A7672] font-mono block mb-4">
            Order Created
          </span>
          <h1
            className="font-editorial font-bold text-[#0D0D0D] mb-4 leading-none"
            style={{ fontSize: "clamp(40px, 6vw, 72px)", letterSpacing: "-0.04em" }}
          >
            VIBE<br />CREATED.
          </h1>
          <p className="text-[#7A7672] text-base">
            Your order is created. Complete the UPI payment below, then submit the transaction reference for verification.
          </p>
        </div>

        {payment && order && (
          <div className="border border-[#E0DDD8] mb-10 p-6">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <img src={payment.payment.qrUrl} alt="VibeWeave UPI payment QR" className="w-56 h-56 object-contain border border-[#E0DDD8] bg-white p-2" />
              <div className="flex-1 w-full">
                <span className="text-[11px] tracking-[0.15em] uppercase text-[#7A7672] font-mono">Pay by UPI</span>
                <h2 className="font-editorial font-bold text-2xl text-[#0D0D0D] mt-2 mb-3">₹{order.totalAmount}</h2>
                <p className="text-sm text-[#7A7672] mb-4">Scan the QR with any UPI app. Confirm the recipient details in your UPI app before paying.</p>
                <div className="space-y-1 text-sm mb-5">
                  {payment.payment.name && <p><strong>Name:</strong> {payment.payment.name}</p>}
                  {payment.payment.upiId && <p><strong>UPI ID:</strong> {payment.payment.upiId}</p>}
                  {payment.payment.phone && <p><strong>Phone:</strong> {payment.payment.phone}</p>}
                </div>
                <div className="flex gap-2">
                  <input value={transactionReference} onChange={(e) => setTransactionReference(e.target.value)} placeholder="UPI transaction / UTR number" className="flex-1 border border-[#E0DDD8] px-4 py-3 text-sm bg-[#FAF8F5]" />
                  <button onClick={submitPayment} disabled={paymentSubmitting || !transactionReference.trim()} className="bg-[#0D0D0D] text-[#FAF8F5] px-5 py-3 text-[11px] uppercase tracking-wider font-bold disabled:opacity-40">{paymentSubmitting ? "Submitting" : "Submit"}</button>
                </div>
                {paymentMessage && <p className="text-sm mt-3 text-[#0D0D0D]">{paymentMessage}</p>}
              </div>
            </div>
          </div>
        )}

        {/* Order details */}
        {order && (
          <div className="border border-[#E0DDD8] mb-10">
            <div className="border-b border-[#E0DDD8] px-6 py-4 flex items-center justify-between">
              <span className="text-[11px] tracking-[0.15em] uppercase text-[#7A7672] font-mono">Order Details</span>
              <span className="font-mono text-[13px] text-[#0D0D0D] font-bold">{order.id}</span>
            </div>
            <div className="px-6 py-4 space-y-0">
              {[
                { label: "Garment", value: order.garment?.replace(/-/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase()) },
                { label: "Colour", value: order.color },
                { label: "Size", value: order.size },
                { label: "Print Size", value: order.printSize },
                { label: "Clothing ×", value: order.clothingQty?.toString() },
                { label: "Design ×", value: order.designQty?.toString() },
                {
                  label: "Delivery",
                  value:
                    order.deliveryMethod === "pickup"
                      ? `Pickup — ${order.pickupPerson ? order.pickupPerson.charAt(0).toUpperCase() + order.pickupPerson.slice(1) : ""}`
                      : `${order.deliverySpeed === "express" ? "Express" : "Normal"} delivery${order.customerCity ? ` to ${order.customerCity}` : ""}`,
                },
              ].map((item) => (
                <div key={item.label} className="flex justify-between py-3 border-b border-[#E0DDD8] last:border-0">
                  <span className="text-[11px] tracking-[0.08em] uppercase text-[#7A7672] font-mono">{item.label}</span>
                  <span className="text-sm font-medium text-[#0D0D0D] capitalize">{item.value}</span>
                </div>
              ))}
              <div className="flex justify-between py-4 bg-[#F0EDE8] -mx-6 px-6 mt-0">
                <span className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono">Order Total</span>
                <span className="font-editorial font-bold text-[#0D0D0D] text-xl">₹{order.totalAmount}</span>
              </div>
            </div>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-4">
          <Link
            href="/"
            className="flex-1 py-4 text-center border border-[#E0DDD8] text-[12px] tracking-[0.1em] uppercase font-mono text-[#7A7672] hover:text-[#0D0D0D] hover:border-[#0D0D0D] transition-colors"
          >
            ← Back to Home
          </Link>
          <Link
            href="/studio"
            className="flex-1 py-4 text-center bg-[#0D0D0D] text-[#FAF8F5] text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors"
          >
            Create Another →
          </Link>
        </div>
      </div>

    </div>
  );
}

export default function ConfirmationPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#FAF8F5] flex items-center justify-center"><div className="font-mono text-[#7A7672]">Loading...</div></div>}>
      <ConfirmationContent />
    </Suspense>
  );
}
