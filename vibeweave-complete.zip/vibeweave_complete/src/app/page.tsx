"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import Nav from "@/components/Nav";

const HERO_IMAGES = {
  campaign: "https://images.pexels.com/photos/5236991/pexels-photo-5236991.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920",
  secondary: "https://images.pexels.com/photos/21429981/pexels-photo-21429981.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920",
  lookbook1: "https://images.pexels.com/photos/8973460/pexels-photo-8973460.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
};

const PRODUCTS_PREVIEW = [
  {
    id: "oversized",
    label: "03",
    name: "Oversized Tee",
    tag: "STREET PICK",
    image: "https://images.pexels.com/photos/18584221/pexels-photo-18584221.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=900",
    size: "large",
  },
  {
    id: "polo",
    label: "02",
    name: "Polo",
    tag: "CLASSIC",
    image: "https://images.pexels.com/photos/24509673/pexels-photo-24509673.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    size: "small",
  },
  {
    id: "round-neck",
    label: "01",
    name: "Round Neck",
    tag: "BESTSELLER",
    image: "https://images.pexels.com/photos/30710033/pexels-photo-30710033.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    size: "small",
  },
  {
    id: "hoodie",
    label: "05",
    name: "Hoodie",
    tag: "WINTER READY",
    image: "https://images.pexels.com/photos/30257616/pexels-photo-30257616.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    size: "medium",
  },
  {
    id: "kids",
    label: "04",
    name: "Kids Tee",
    tag: "KIDS",
    image: "https://images.pexels.com/photos/36317737/pexels-photo-36317737.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    size: "small",
  },
];

export default function HomePage() {
  const [introComplete, setIntroComplete] = useState(false);
  const [introVisible, setIntroVisible] = useState(true);
  const [heroVisible, setHeroVisible] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Intro animation sequence
    const t1 = setTimeout(() => setIntroComplete(true), 1800);
    const t2 = setTimeout(() => {
      setIntroVisible(false);
      setHeroVisible(true);
    }, 2400);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  // Parallax
  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scrollY = window.scrollY;
        heroRef.current.style.transform = `translateY(${scrollY * 0.4}px)`;
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="relative bg-[#FAF8F5] min-h-screen overflow-x-hidden">
      {/* INTRO OVERLAY */}
      <div
        className="fixed inset-0 z-[100] flex items-center justify-center bg-[#FAF8F5] pointer-events-none"
        style={{
          opacity: introVisible ? 1 : 0,
          transition: "opacity 0.6s ease-in-out",
          pointerEvents: introVisible ? "none" : "none",
        }}
      >
        <div
          className="font-editorial font-bold text-[#0D0D0D] select-none"
          style={{
            fontSize: "clamp(32px, 8vw, 96px)",
            letterSpacing: "-0.04em",
            transform: introComplete ? "scale(1.08)" : "scale(0.92)",
            opacity: introComplete ? 0 : 1,
            filter: introComplete ? "blur(8px)" : "blur(0px)",
            transition:
              "transform 1.8s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.5s ease-in, filter 0.5s ease-in",
          }}
        >
          VIBEWEAVE
        </div>
      </div>

      <Nav />

      {/* HERO */}
      <section
        className="relative min-h-screen flex flex-col overflow-hidden"
        style={{
          opacity: heroVisible ? 1 : 0,
          transition: "opacity 0.8s ease-in-out",
        }}
      >
        {/* Background image with parallax */}
        <div className="absolute inset-0 overflow-hidden">
          <div ref={heroRef} className="absolute inset-0 scale-110">
            <Image
              src={HERO_IMAGES.campaign}
              alt="VibeWeave campaign"
              fill
              priority
              className="object-cover object-center"
              sizes="100vw"
            />
          </div>
          {/* Gradient overlays for text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#0D0D0D]/80 via-[#0D0D0D]/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/60 via-transparent to-[#0D0D0D]/20" />
        </div>

        {/* Hero content */}
        <div className="relative z-10 flex flex-col justify-end min-h-screen pb-16 md:pb-24 px-6 md:px-16 lg:px-20">
          {/* Brand badge */}
          <div className="mb-6">
            <span className="text-[11px] text-[#FAF8F5]/60 tracking-[0.2em] uppercase font-mono">
              VIBEWEAVE®
            </span>
          </div>

          {/* Main headline */}
          <h1
            className="font-editorial font-bold text-[#FAF8F5] leading-[0.92] mb-6"
            style={{ fontSize: "clamp(64px, 12vw, 160px)", letterSpacing: "-0.04em" }}
          >
            WEAR
            <br />
            YOUR
            <br />
            <span className="text-[#C8FF00]">VIBE.</span>
          </h1>

          {/* Supporting line */}
          <p className="text-[#FAF8F5]/70 text-base md:text-lg font-light mb-8 max-w-md">
            Your design. Your garment. Your way.
          </p>

          {/* CTA */}
          <div className="flex items-center gap-6">
            <Link
              href="/studio"
              className="group flex items-center gap-3 bg-[#C8FF00] text-[#0D0D0D] px-8 py-4 text-[13px] tracking-[0.1em] uppercase font-bold hover:bg-[#FAF8F5] transition-colors duration-300"
            >
              Start Creating
              <span className="inline-block transition-transform duration-300 group-hover:translate-x-2">→</span>
            </Link>
            <Link
              href="/shop"
              className="text-[#FAF8F5]/80 text-[13px] tracking-[0.1em] uppercase font-medium border-b border-[#FAF8F5]/40 pb-0.5 hover:text-[#FAF8F5] hover:border-[#FAF8F5] transition-colors"
            >
              View Collection
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 right-8 md:right-16 z-10 flex flex-col items-center gap-2">
          <div className="w-px h-12 bg-[#FAF8F5]/30 animate-pulse" />
          <span className="text-[10px] tracking-[0.2em] uppercase text-[#FAF8F5]/50 font-mono -rotate-90 mt-2">
            Scroll
          </span>
        </div>
      </section>

      {/* ANNOUNCEMENT BAR */}
      <div
        className="bg-[#0D0D0D] text-[#FAF8F5] overflow-hidden"
        style={{
          opacity: heroVisible ? 1 : 0,
          transition: "opacity 0.8s ease-in-out 0.2s",
        }}
      >
        <div className="flex whitespace-nowrap animate-[marquee_20s_linear_infinite] py-3">
          {Array(6)
            .fill(null)
            .map((_, i) => (
              <span key={i} className="text-[11px] tracking-[0.15em] uppercase font-mono px-8">
                CUSTOM APPAREL •&nbsp; PURE COTTON •&nbsp; WEAR YOUR VIBE •&nbsp; VIBEWEAVE® •&nbsp;
              </span>
            ))}
        </div>
      </div>

      {/* THE PIECES — Lookbook section */}
      <section
        className="py-20 md:py-32 px-6 md:px-12 lg:px-20"
        style={{
          opacity: heroVisible ? 1 : 0,
          transition: "opacity 0.8s ease-in-out 0.4s",
        }}
      >
        {/* Section header */}
        <div className="flex items-end justify-between mb-12 md:mb-16">
          <div>
            <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-3">
              Collection 2025
            </span>
            <h2
              className="font-editorial font-bold text-[#0D0D0D] leading-none"
              style={{ fontSize: "clamp(40px, 6vw, 80px)", letterSpacing: "-0.03em" }}
            >
              THE PIECES
            </h2>
          </div>
          <Link
            href="/shop"
            className="hidden md:flex items-center gap-2 text-[12px] tracking-[0.1em] uppercase font-medium text-[#7A7672] hover:text-[#0D0D0D] transition-colors border-b border-[#7A7672]/40 pb-0.5"
          >
            View All →
          </Link>
        </div>

        {/* Editorial layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6">
          {/* Large feature — Oversized Tee */}
          <Link
            href="/shop?product=oversized"
            className="group md:col-span-5 md:row-span-2 relative overflow-hidden bg-[#E8E4DD] aspect-[3/4] block"
          >
            <Image
              src={PRODUCTS_PREVIEW[0].image}
              alt="Oversized Tee"
              fill
              className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, 45vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/60 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 p-6">
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#C8FF00] font-mono block mb-1">
                {PRODUCTS_PREVIEW[0].tag}
              </span>
              <h3 className="font-editorial font-bold text-[#FAF8F5] text-2xl leading-tight" style={{ letterSpacing: "-0.02em" }}>
                Oversized<br />Tee
              </h3>
              <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="text-[11px] tracking-[0.1em] uppercase text-[#FAF8F5]/80">Customize →</span>
              </div>
            </div>
            <div className="absolute top-4 left-4">
              <span className="font-mono text-[11px] text-[#FAF8F5]/50">03</span>
            </div>
          </Link>

          {/* Polo — medium portrait */}
          <Link
            href="/shop?product=polo"
            className="group md:col-span-4 relative overflow-hidden bg-[#F0EDE8] aspect-[4/5] block"
          >
            <Image
              src={PRODUCTS_PREVIEW[1].image}
              alt="Polo T-Shirt"
              fill
              className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, 33vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/50 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 p-5">
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-1">
                {PRODUCTS_PREVIEW[1].tag}
              </span>
              <h3 className="font-editorial font-bold text-[#FAF8F5] text-xl" style={{ letterSpacing: "-0.02em" }}>
                Polo
              </h3>
            </div>
            <div className="absolute top-4 left-4">
              <span className="font-mono text-[11px] text-[#FAF8F5]/50">02</span>
            </div>
          </Link>

          {/* Round Neck — small portrait */}
          <Link
            href="/shop?product=round-neck"
            className="group md:col-span-3 relative overflow-hidden bg-[#E8E8E4] aspect-[4/5] block"
          >
            <Image
              src={PRODUCTS_PREVIEW[2].image}
              alt="Round Neck T-Shirt"
              fill
              className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, 25vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/60 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 p-4">
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#C8FF00] font-mono block mb-1">
                {PRODUCTS_PREVIEW[2].tag}
              </span>
              <h3 className="font-editorial font-bold text-[#FAF8F5] text-lg" style={{ letterSpacing: "-0.02em" }}>
                Round<br />Neck
              </h3>
            </div>
            <div className="absolute top-4 left-4">
              <span className="font-mono text-[11px] text-[#FAF8F5]/50">01</span>
            </div>
          </Link>

          {/* Hoodie — wide */}
          <Link
            href="/shop?product=hoodie"
            className="group md:col-span-4 relative overflow-hidden bg-[#1A1A1A] aspect-[4/3] md:aspect-auto block"
          >
            <Image
              src={PRODUCTS_PREVIEW[3].image}
              alt="Cotton Hoodie"
              fill
              className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, 33vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/70 via-[#0D0D0D]/10 to-transparent" />
            <div className="absolute bottom-0 left-0 p-5">
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#C8FF00] font-mono block mb-1">
                {PRODUCTS_PREVIEW[3].tag}
              </span>
              <h3 className="font-editorial font-bold text-[#FAF8F5] text-xl" style={{ letterSpacing: "-0.02em" }}>
                Hoodie
              </h3>
            </div>
            <div className="absolute top-4 left-4">
              <span className="font-mono text-[11px] text-[#FAF8F5]/50">05</span>
            </div>
          </Link>

          {/* Kids */}
          <Link
            href="/shop?product=kids"
            className="group md:col-span-3 relative overflow-hidden bg-[#F0ECE4] aspect-[4/3] md:aspect-auto block"
          >
            <Image
              src={PRODUCTS_PREVIEW[4].image}
              alt="Kids T-Shirt"
              fill
              className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, 25vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/50 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 p-5">
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-1">
                {PRODUCTS_PREVIEW[4].tag}
              </span>
              <h3 className="font-editorial font-bold text-[#FAF8F5] text-xl" style={{ letterSpacing: "-0.02em" }}>
                Kids
              </h3>
            </div>
            <div className="absolute top-4 left-4">
              <span className="font-mono text-[11px] text-[#FAF8F5]/50">04</span>
            </div>
          </Link>
        </div>

        <div className="mt-8 md:hidden text-center">
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 text-[12px] tracking-[0.1em] uppercase font-medium text-[#7A7672] border-b border-[#7A7672]/40 pb-0.5"
          >
            View All →
          </Link>
        </div>
      </section>

      {/* STUDIO CTA SECTION */}
      <section className="relative overflow-hidden bg-[#0D0D0D] py-24 md:py-36 px-6 md:px-20">
        <div className="absolute inset-0">
          <Image
            src={HERO_IMAGES.secondary}
            alt="VibeWeave Studio"
            fill
            className="object-cover object-center opacity-20"
            sizes="100vw"
          />
        </div>
        <div className="relative z-10 max-w-3xl">
          <span className="text-[11px] tracking-[0.25em] uppercase text-[#7A7672] font-mono block mb-6">
            Vibeweave Studio
          </span>
          <h2
            className="font-editorial font-bold text-[#FAF8F5] mb-8 leading-none"
            style={{ fontSize: "clamp(40px, 7vw, 96px)", letterSpacing: "-0.04em" }}
          >
            CREATE YOUR
            <br />
            <span className="text-[#C8FF00]">CUSTOM PIECE.</span>
          </h2>
          <p className="text-[#FAF8F5]/60 text-base md:text-lg max-w-md mb-10 font-light">
            Choose your garment, upload your artwork, pick your print size and colour. We handle the rest.
          </p>
          <Link
            href="/studio"
            className="group inline-flex items-center gap-3 bg-[#C8FF00] text-[#0D0D0D] px-10 py-5 text-[13px] tracking-[0.1em] uppercase font-bold hover:bg-[#FAF8F5] transition-colors duration-300"
          >
            Open Studio
            <span className="inline-block transition-transform duration-300 group-hover:translate-x-2">→</span>
          </Link>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-20 md:py-28 px-6 md:px-20">
        <div className="mb-12">
          <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-3">
            The Process
          </span>
          <h2
            className="font-editorial font-bold text-[#0D0D0D] leading-none"
            style={{ fontSize: "clamp(32px, 5vw, 60px)", letterSpacing: "-0.03em" }}
          >
            HOW IT WORKS
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-4">
          {[
            { step: "01", title: "Pick Your Piece", desc: "Choose from 5 premium cotton garments in 12 colours." },
            { step: "02", title: "Upload Your Art", desc: "Drop your design. Position it exactly where you want." },
            { step: "03", title: "Size & Quantity", desc: "Select print size from A7 to A2. Set clothing and design quantities." },
            { step: "04", title: "Deliver or Pick Up", desc: "Get it delivered or collect from Srijit or Ayaan." },
          ].map((item, i) => (
            <div key={i} className="group">
              <div className="font-mono text-[11px] text-[#7A7672] mb-6 flex items-center gap-4">
                <span>{item.step}</span>
                {i < 3 && <div className="flex-1 h-px bg-[#E0DDD8] hidden md:block" />}
              </div>
              <h3
                className="font-editorial font-bold text-[#0D0D0D] mb-3"
                style={{ fontSize: "20px", letterSpacing: "-0.02em" }}
              >
                {item.title}
              </h3>
              <p className="text-[#7A7672] text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* LOOKBOOK STRIP */}
      <section className="py-4 overflow-hidden">
        <div className="flex gap-4 overflow-x-auto pb-4 px-6 md:px-12 scrollbar-none" style={{ scrollbarWidth: "none" }}>
          {[
            "https://images.pexels.com/photos/7645800/pexels-photo-7645800.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450",
            "https://images.pexels.com/photos/10378761/pexels-photo-10378761.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450",
            "https://images.pexels.com/photos/8973455/pexels-photo-8973455.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450",
            "https://images.pexels.com/photos/8973460/pexels-photo-8973460.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450",
            "https://images.pexels.com/photos/7236167/pexels-photo-7236167.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450",
          ].map((src, i) => (
            <div key={i} className="flex-none w-56 md:w-72 h-72 md:h-96 relative overflow-hidden group bg-[#E8E4DD]">
              <Image
                src={src}
                alt={`Lookbook ${i + 1}`}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
                sizes="288px"
              />
            </div>
          ))}
        </div>
      </section>

      {/* COLOURS PREVIEW */}
      <section className="py-16 px-6 md:px-20 bg-[#F2EFE9]">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
          <div>
            <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-2">
              12 Colours Available
            </span>
            <h2
              className="font-editorial font-bold text-[#0D0D0D]"
              style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}
            >
              YOUR PALETTE
            </h2>
          </div>
          <Link href="/studio" className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] border-b border-[#7A7672]/40 pb-0.5 hover:text-[#0D0D0D] transition-colors self-start md:self-auto">
            Customise Now →
          </Link>
        </div>
        <div className="flex flex-wrap gap-3">
          {[
            { name: "Blue", hex: "#3B6FD4" },
            { name: "Red", hex: "#8B1A1A" },
            { name: "Dark Grey", hex: "#2C2C2C" },
            { name: "Light Cyan", hex: "#A8DFDC" },
            { name: "Pink", hex: "#E8A0B0" },
            { name: "Mint Green", hex: "#5EC4A8" },
            { name: "Coral", hex: "#E87060" },
            { name: "Bright Red", hex: "#E02020" },
            { name: "Yellow", hex: "#F0B820" },
            { name: "Black", hex: "#0D0D0D" },
            { name: "Light Grey", hex: "#BEBEBE" },
            { name: "Off-White", hex: "#EDE8DF" },
          ].map((color) => (
            <div key={color.name} className="flex flex-col items-center gap-1.5">
              <div
                className="w-10 h-10 rounded-full border border-[#0D0D0D]/10 transition-transform hover:scale-110 cursor-pointer"
                style={{ backgroundColor: color.hex }}
                title={color.name}
              />
              <span className="text-[9px] tracking-[0.1em] text-[#7A7672] uppercase font-mono hidden md:block">
                {color.name}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#0D0D0D] text-[#FAF8F5] py-16 px-6 md:px-20">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-10 mb-12">
          <div className="max-w-xs">
            <div
              className="font-editorial font-bold mb-3"
              style={{ fontSize: "28px", letterSpacing: "-0.04em" }}
            >
              VIBEWEAVE
            </div>
            <p className="text-[#FAF8F5]/50 text-sm leading-relaxed">
              Custom apparel made with premium cotton. Your design, your way.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8 text-sm">
            <div>
              <p className="text-[11px] tracking-[0.15em] uppercase text-[#7A7672] font-mono mb-4">Explore</p>
              {[
                { href: "/", label: "Home" },
                { href: "/shop", label: "Shop" },
                { href: "/studio", label: "Create" },
              ].map((l) => (
                <a key={l.href} href={l.href} className="block text-[#FAF8F5]/60 hover:text-[#FAF8F5] transition-colors mb-2 text-[13px]">
                  {l.label}
                </a>
              ))}
            </div>
            <div>
              <p className="text-[11px] tracking-[0.15em] uppercase text-[#7A7672] font-mono mb-4">Order</p>
              {[
                { href: "/my-order", label: "My Order" },
                { href: "/studio", label: "Start Creating" },
              ].map((l) => (
                <a key={l.href} href={l.href} className="block text-[#FAF8F5]/60 hover:text-[#FAF8F5] transition-colors mb-2 text-[13px]">
                  {l.label}
                </a>
              ))}
            </div>
            <div>
              <p className="text-[11px] tracking-[0.15em] uppercase text-[#7A7672] font-mono mb-4">Pickup</p>
              <p className="text-[#FAF8F5]/60 text-[13px] mb-2">Srijit</p>
              <p className="text-[#FAF8F5]/60 text-[13px]">Ayaan</p>
            </div>
          </div>
        </div>
        <div className="border-t border-[#FAF8F5]/10 pt-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <p className="text-[11px] tracking-[0.08em] text-[#FAF8F5]/30 font-mono">
            © 2025 VIBEWEAVE. ALL RIGHTS RESERVED.
          </p>
          <p className="text-[11px] text-[#FAF8F5]/30 font-mono tracking-wider">WEAR YOUR VIBE.</p>
        </div>
      </footer>

    </div>
  );
}
