"use client";
import { Suspense } from "react";
import StudioContent from "@/components/studio/StudioContent";

export default function StudioPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#FAF8F5] flex items-center justify-center">
          <div className="font-mono text-[#7A7672] text-sm tracking-widest">LOADING STUDIO...</div>
        </div>
      }
    >
      <StudioContent />
    </Suspense>
  );
}
