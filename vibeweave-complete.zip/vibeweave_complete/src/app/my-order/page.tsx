"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Nav from "@/components/Nav";
import { useOrderStore } from "@/store/orderStore";

interface OrderData {
  id: string;
  garment: string;
  color: string;
  size: string;
  printSize: string;
  clothingQty: number;
  designQty: number;
  deliveryMethod: string;
  pickupPerson?: string;
  customerName?: string;
  customerCity?: string;
  totalAmount: number;
  status: string;
  createdAt: string;
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { bg: string; text: string; label: string }> = {
    payment_pending: { bg: "bg-[#F0EDE8]", text: "text-[#7A7672]", label: "Payment Pending" },
    paid: { bg: "bg-[#C8FF00]", text: "text-[#0D0D0D]", label: "Paid" },
    pending: { bg: "bg-[#F0EDE8]", text: "text-[#7A7672]", label: "Pending" },
    processing: { bg: "bg-[#0D0D0D]", text: "text-[#FAF8F5]", label: "Processing" },
    shipped: { bg: "bg-[#3B6FD4]", text: "text-[#FAF8F5]", label: "Shipped" },
    delivered: { bg: "bg-[#5EC4A8]", text: "text-[#FAF8F5]", label: "Delivered" },
  };
  const style = map[status] ?? map.pending;
  return (
    <span className={`${style.bg} ${style.text} text-[10px] tracking-[0.1em] uppercase font-mono px-2 py-1`}>
      {style.label}
    </span>
  );
}

export default function MyOrderPage() {
  const [orders, setOrders] = useState<OrderData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchId, setSearchId] = useState("");
  const [searched, setSearched] = useState(false);
  const storedOrderId = useOrderStore((s) => s.orderId);

  useEffect(() => {
    if (storedOrderId) {
      setSearchId(storedOrderId);
      fetchById(storedOrderId);
    } else {
      setLoading(false);
    }
  }, [storedOrderId]);

  const fetchById = async (id: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orders?id=${encodeURIComponent(id)}`);
      const data = await res.json();
      if (data.success) setOrders([data.order]);
      else setOrders([]);
    } catch {
      setOrders([]);
    } finally {
      setLoading(false);
      setSearched(true);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchId.trim()) fetchById(searchId.trim());
  };

  function formatDate(dateStr: string) {
    try {
      return new Date(dateStr).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
    } catch {
      return "—";
    }
  }

  return (
    <div className="min-h-screen bg-[#FAF8F5]">
      <Nav />
      <div className="max-w-3xl mx-auto px-6 md:px-12 pt-28 pb-20">
        <div className="mb-10">
          <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-3">
            Order Tracker
          </span>
          <h1
            className="font-editorial font-bold text-[#0D0D0D] leading-none"
            style={{ fontSize: "clamp(36px, 5vw, 64px)", letterSpacing: "-0.04em" }}
          >
            MY ORDER
          </h1>
        </div>

        {/* Search */}
        <form onSubmit={handleSearch} className="flex gap-3 mb-12">
          <input
            type="text"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            placeholder="Enter Order ID (e.g. VW-...)"
            className="flex-1 border border-[#E0DDD8] bg-[#FAF8F5] px-4 py-3 text-[#0D0D0D] text-sm focus:outline-none focus:border-[#0D0D0D] transition-colors font-mono placeholder:text-[#BEBEBE]"
          />
          <button
            type="submit"
            className="bg-[#0D0D0D] text-[#FAF8F5] px-6 py-3 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors"
          >
            Track
          </button>
        </form>

        {/* Results */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-6 h-6 border-2 border-[#0D0D0D] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : orders.length > 0 ? (
          <div className="space-y-6">
            {orders.map((order) => (
              <div key={order.id} className="border border-[#E0DDD8]">
                {/* Order header */}
                <div className="border-b border-[#E0DDD8] px-6 py-4 flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <span className="font-mono text-[13px] font-bold text-[#0D0D0D] block">{order.id}</span>
                    <span className="font-mono text-[11px] text-[#7A7672]">{formatDate(order.createdAt)}</span>
                  </div>
                  <StatusBadge status={order.status} />
                </div>

                {/* Order body */}
                <div className="px-6 py-4">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                    {[
                      { label: "Garment", value: order.garment?.replace(/-/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase()) },
                      { label: "Colour", value: order.color },
                      { label: "Size", value: order.size },
                      { label: "Print Size", value: order.printSize },
                      { label: "Clothing ×", value: order.clothingQty?.toString() },
                      { label: "Design ×", value: order.designQty?.toString() },
                    ].map((item) => (
                      <div key={item.label}>
                        <p className="text-[10px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-1">{item.label}</p>
                        <p className="font-medium text-[#0D0D0D] text-sm capitalize">{item.value}</p>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-[#E0DDD8] pt-4 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-1">Delivery</p>
                      <p className="text-sm font-medium text-[#0D0D0D] capitalize">
                        {order.deliveryMethod === "pickup"
                          ? `Pickup from ${order.pickupPerson || "—"}`
                          : `Delivery${order.customerCity ? ` to ${order.customerCity}` : ""}`}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-1">Total</p>
                      <p className="font-editorial font-bold text-[#0D0D0D] text-xl">₹{order.totalAmount}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : searched ? (
          <div className="text-center py-20">
            <div className="text-4xl mb-4">🔍</div>
            <p className="font-editorial font-bold text-[#0D0D0D] text-xl mb-2" style={{ letterSpacing: "-0.02em" }}>
              Order not found
            </p>
            <p className="text-[#7A7672] text-sm mb-8">Double-check your order ID and try again.</p>
            <Link href="/studio" className="inline-flex items-center gap-2 bg-[#0D0D0D] text-[#FAF8F5] px-6 py-3 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors">
              Create New Order →
            </Link>
          </div>
        ) : (
          <div className="text-center py-20 border border-dashed border-[#E0DDD8]">
            <div className="text-4xl mb-6">📦</div>
            <p className="font-editorial font-bold text-[#0D0D0D] text-xl mb-2" style={{ letterSpacing: "-0.02em" }}>
              Track your order
            </p>
            <p className="text-[#7A7672] text-sm mb-8">Enter your order ID to see order status and details.</p>
            <Link href="/studio" className="inline-flex items-center gap-2 bg-[#0D0D0D] text-[#FAF8F5] px-6 py-3 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors">
              Start Creating →
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
