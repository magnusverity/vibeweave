import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "VIBEWEAVE — Wear Your Vibe",
  description: "Custom apparel studio. Your design. Your garment. Your way.",
  openGraph: {
    title: "VIBEWEAVE",
    description: "Wear Your Vibe. Custom apparel made yours.",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
