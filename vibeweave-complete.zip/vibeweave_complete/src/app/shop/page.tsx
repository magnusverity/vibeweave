"use client";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense } from "react";
import Image from "next/image";
import Link from "next/link";
import Nav from "@/components/Nav";
import { PRODUCTS } from "@/lib/constants";

const PRODUCT_IMAGES = {
  "round-neck": {
    main: "https://images.pexels.com/photos/30710033/pexels-photo-30710033.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    alt: "https://images.pexels.com/photos/37704848/pexels-photo-37704848.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
  polo: {
    main: "https://images.pexels.com/photos/24509673/pexels-photo-24509673.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    alt: "https://images.pexels.com/photos/39317887/pexels-photo-39317887.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
  oversized: {
    main: "https://images.pexels.com/photos/18584221/pexels-photo-18584221.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    alt: "https://images.pexels.com/photos/30257616/pexels-photo-30257616.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
  kids: {
    main: "https://images.pexels.com/photos/36317737/pexels-photo-36317737.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    alt: "https://images.pexels.com/photos/9587495/pexels-photo-9587495.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
  hoodie: {
    main: "https://images.pexels.com/photos/4118957/pexels-photo-4118957.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    alt: "https://images.pexels.com/photos/7263105/pexels-photo-7263105.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
};

function ShopContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const selectedProduct = searchParams.get("product") ?? "";

  const selected = PRODUCTS.find((p) => p.id === selectedProduct) ?? null;

  return (
    <div className="min-h-screen bg-[#FAF8F5]">
      <Nav />

      {/* Header */}
      <div className="pt-24 pb-8 px-6 md:px-12 lg:px-20 border-b border-[#E0DDD8]">
        <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-3">
          Collection 2025
        </span>
        <h1
          className="font-editorial font-bold text-[#0D0D0D] leading-none"
          style={{ fontSize: "clamp(40px, 6vw, 80px)", letterSpacing: "-0.03em" }}
        >
          THE PIECES
        </h1>
      </div>

      <div className="px-6 md:px-12 lg:px-20 py-12">
        {/* Detail view */}
        {selected ? (
          <div>
            <button
              onClick={() => router.push("/shop")}
              className="flex items-center gap-2 text-[12px] tracking-[0.08em] uppercase text-[#7A7672] mb-10 hover:text-[#0D0D0D] transition-colors"
            >
              ← All Pieces
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
              {/* Images */}
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2 aspect-[4/5] relative overflow-hidden bg-[#E8E4DD]">
                  <Image
                    src={PRODUCT_IMAGES[selected.id as keyof typeof PRODUCT_IMAGES]?.main}
                    alt={selected.name}
                    fill
                    className="object-cover object-top"
                    sizes="(max-width: 768px) 100vw, 50vw"
                    priority
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-[#C8FF00] text-[#0D0D0D] text-[10px] tracking-[0.1em] uppercase px-2 py-1 font-mono font-bold">
                      {selected.tag}
                    </span>
                  </div>
                </div>
                <div className="aspect-[4/5] relative overflow-hidden bg-[#F0EDE8]">
                  <Image
                    src={PRODUCT_IMAGES[selected.id as keyof typeof PRODUCT_IMAGES]?.alt}
                    alt={`${selected.name} detail`}
                    fill
                    className="object-cover object-top"
                    sizes="25vw"
                  />
                </div>
                <div className="aspect-[4/5] relative overflow-hidden bg-[#E8E8E4] flex items-center justify-center">
                  <div className="text-center p-6">
                    <div
                      className="font-editorial font-bold text-[#0D0D0D]/20 mb-3"
                      style={{ fontSize: "60px", letterSpacing: "-0.04em" }}
                    >
                      {selected.label}
                    </div>
                    <p className="text-[11px] tracking-[0.15em] uppercase text-[#7A7672] font-mono">
                      {selected.shortName}
                    </p>
                  </div>
                </div>
              </div>

              {/* Info */}
              <div className="py-4">
                <div className="mb-2">
                  <span className="font-mono text-[11px] text-[#7A7672] tracking-[0.15em]">{selected.label}</span>
                </div>
                <h2
                  className="font-editorial font-bold text-[#0D0D0D] mb-4 leading-tight"
                  style={{ fontSize: "clamp(28px, 3vw, 42px)", letterSpacing: "-0.03em" }}
                >
                  {selected.name}
                </h2>
                <p className="text-[#7A7672] text-sm leading-relaxed mb-8">{selected.description}</p>

                <div className="border-t border-[#E0DDD8] pt-8 mb-8">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono">Base Price</span>
                    <span className="font-editorial font-bold text-[#0D0D0D] text-xl">₹{selected.basePrice}</span>
                  </div>
                  <p className="text-[11px] text-[#7A7672]">+ print size & design fees at checkout</p>
                </div>

                <div className="mb-8">
                  <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-4">Sizes</p>
                  <div className="flex gap-2 flex-wrap">
                    {["M", "L", "XL", "2XL", "XXL"].map((s) => (
                      <div
                        key={s}
                        className="w-12 h-12 flex items-center justify-center border border-[#E0DDD8] text-[13px] font-medium text-[#0D0D0D]"
                      >
                        {s}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mb-10">
                  <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-4">12 Colours</p>
                  <div className="flex flex-wrap gap-2">
                    {[
                      "#3B6FD4", "#8B1A1A", "#2C2C2C", "#A8DFDC",
                      "#E8A0B0", "#5EC4A8", "#E87060", "#E02020",
                      "#F0B820", "#0D0D0D", "#BEBEBE", "#EDE8DF",
                    ].map((hex) => (
                      <div
                        key={hex}
                        className="w-8 h-8 rounded-full border border-[#0D0D0D]/10"
                        style={{ backgroundColor: hex }}
                      />
                    ))}
                  </div>
                </div>

                <Link
                  href={`/studio?product=${selected.id}`}
                  className="group flex items-center justify-center gap-3 bg-[#0D0D0D] text-[#FAF8F5] py-4 text-[13px] tracking-[0.1em] uppercase font-bold w-full hover:bg-[#1A1A1A] transition-colors"
                >
                  Customize This Piece
                  <span className="transition-transform duration-300 group-hover:translate-x-2">→</span>
                </Link>
              </div>
            </div>
          </div>
        ) : (
          /* Grid view */
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {PRODUCTS.map((product) => (
                <Link
                  key={product.id}
                  href={`/shop?product=${product.id}`}
                  className="group block"
                >
                  {/* Image */}
                  <div className="aspect-[4/5] relative overflow-hidden bg-[#E8E4DD] mb-4">
                    <Image
                      src={PRODUCT_IMAGES[product.id as keyof typeof PRODUCT_IMAGES]?.main}
                      alt={product.name}
                      fill
                      className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-[#C8FF00] text-[#0D0D0D] text-[10px] tracking-[0.1em] uppercase px-2 py-1 font-mono font-bold">
                        {product.tag}
                      </span>
                    </div>
                    <div className="absolute top-4 right-4">
                      <span className="font-mono text-[11px] text-[#FAF8F5]/60">{product.label}</span>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-[#0D0D0D]/60 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-400">
                      <span className="text-[11px] tracking-[0.1em] uppercase text-[#FAF8F5] font-medium">
                        Customize →
                      </span>
                    </div>
                  </div>
                  {/* Info */}
                  <div className="flex items-start justify-between">
                    <div>
                      <h3
                        className="font-editorial font-bold text-[#0D0D0D] mb-1"
                        style={{ fontSize: "18px", letterSpacing: "-0.02em" }}
                      >
                        {product.name}
                      </h3>
                      <p className="text-[#7A7672] text-sm">{product.description}</p>
                    </div>
                    <span className="font-editorial font-bold text-[#0D0D0D] text-lg ml-4">
                      ₹{product.basePrice}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ShopPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#FAF8F5] flex items-center justify-center"><div className="font-mono text-[#7A7672]">Loading...</div></div>}>
      <ShopContent />
    </Suspense>
  );
}
