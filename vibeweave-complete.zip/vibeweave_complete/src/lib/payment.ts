export type PaymentProvider = "manual_upi";

export interface PaymentIntent {
  provider: PaymentProvider;
  reference: string;
  checkoutUrl: string | null;
  payment: { name: string | null; upiId: string | null; phone: string | null; qrUrl: string };
}

export function getUpiConfig() {
  return {
    name: process.env.VIBEWEAVE_PAYMENT_NAME || "Ayaan Khandekar",
    upiId: process.env.VIBEWEAVE_UPI_ID || null,
    phone: process.env.VIBEWEAVE_PAYMENT_PHONE || null,
    qrUrl: "/payment/upi-qr.png",
  };
}

export async function createPaymentIntent(orderId: string, amount: number): Promise<PaymentIntent> {
  void amount;
  return { provider: "manual_upi", reference: `UPI_${orderId}`, checkoutUrl: null, payment: getUpiConfig() };
}
