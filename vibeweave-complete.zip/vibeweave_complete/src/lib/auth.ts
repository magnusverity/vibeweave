import { createHash, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { db } from "@/db";
import { accounts, sessions } from "@/db/schema";
import { eq } from "drizzle-orm";

export const SESSION_COOKIE = "vibeweave_session";
const SESSION_DAYS = 30;

export function normalizeEmail(email: string) { return email.trim().toLowerCase(); }

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `scrypt:${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string) {
  const [scheme, salt, expected] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !expected) return false;
  const actual = scryptSync(password, salt, 64).toString("hex");
  return timingSafeEqual(Buffer.from(actual, "hex"), Buffer.from(expected, "hex"));
}

export function newId(prefix: string) { return `${prefix}_${randomBytes(16).toString("hex")}`; }
export function hashToken(token: string) { return createHash("sha256").update(token).digest("hex"); }

export async function createSession(accountId: string) {
  const raw = randomBytes(32).toString("base64url");
  const id = hashToken(raw);
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ id, accountId, expiresAt });
  const store = await cookies();
  store.set(SESSION_COOKIE, raw, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", expires: expiresAt });
  return { raw, expiresAt };
}

export async function getCurrentAccount() {
  const store = await cookies();
  const raw = store.get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  const id = hashToken(raw);
  const rows = await db.select({ account: accounts, session: sessions }).from(sessions).innerJoin(accounts, eq(sessions.accountId, accounts.id)).where(eq(sessions.id, id)).limit(1);
  const row = rows[0];
  if (!row || row.session.expiresAt <= new Date()) {
    if (row) await db.delete(sessions).where(eq(sessions.id, id));
    return null;
  }
  return row.account;
}

export async function requireAccount() {
  const account = await getCurrentAccount();
  if (!account) throw new Error("UNAUTHORIZED");
  return account;
}

export async function clearSession() {
  const store = await cookies();
  const raw = store.get(SESSION_COOKIE)?.value;
  if (raw) await db.delete(sessions).where(eq(sessions.id, hashToken(raw)));
  store.set(SESSION_COOKIE, "", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", expires: new Date(0) });
}
