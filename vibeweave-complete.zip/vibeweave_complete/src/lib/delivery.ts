export type DeliverySpeed = "normal" | "express";

function envInt(name: string, fallback: number) {
  const n = Number(process.env[name]);
  return Number.isInteger(n) && n >= 0 ? n : fallback;
}

export function getDeliveryOptions() {
  return [
    { id: "normal" as const, label: "Normal Delivery", fee: envInt("NORMAL_DELIVERY_FEE", 0), etaDays: envInt("NORMAL_DELIVERY_ETA_DAYS", 5) },
    { id: "express" as const, label: "Express Delivery", fee: envInt("EXPRESS_DELIVERY_FEE", 0), etaDays: envInt("EXPRESS_DELIVERY_ETA_DAYS", 2) },
  ];
}

export function getDeliveryOption(speed: string) {
  return getDeliveryOptions().find((x) => x.id === speed);
}
