import {
  COLORS,
  PICKUP_PERSONS,
  PRINT_SIZES,
  PRODUCTS,
  SIZES,
  calculateTotal,
} from "@/lib/constants";
import { getDeliveryOption, type DeliverySpeed } from "@/lib/delivery";

export class OrderValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OrderValidationError";
  }
}

export const ORDER_STATUSES = [
  "payment_pending",
  "paid",
  "processing",
  "ready",
  "completed",
  "payment_failed",
  "cancelled",
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export const PAYMENT_STATUSES = ["pending", "paid", "failed", "refunded"] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export type CreateOrderInput = Record<string, unknown>;

export type ValidatedOrderInput = {
  garment: string;
  color: string;
  size: string;
  artworkUrl: string | null;
  artworkPosition: { x: number; y: number; width: number; height: number } | null;
  printSize: string;
  clothingQty: number;
  designQty: number;
  deliveryMethod: "delivery" | "pickup";
  deliverySpeed: DeliverySpeed | null;
  deliveryFee: number;
  deliveryEtaDays: number | null;
  pickupPerson: string | null;
  customerName: string | null;
  customerPhone: string | null;
  customerAddress: string | null;
  customerCity: string | null;
  customerPin: string | null;
  totalAmount: number;
};

const MAX_TEXT = 200;
const MAX_ARTWORK_URL = 2000;

function cleanString(value: unknown, field: string, required = false): string | null {
  if (value == null || value === "") {
    if (required) throw new OrderValidationError(`${field} is required`);
    return null;
  }
  if (typeof value !== "string") throw new OrderValidationError(`${field} must be a string`);
  const result = value.trim();
  if (required && !result) throw new OrderValidationError(`${field} is required`);
  if (result.length > MAX_TEXT) throw new OrderValidationError(`${field} is too long`);
  return result || null;
}

function positiveInt(value: unknown, field: string, min = 1, max = 100): number {
  const number = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(number) || number < min || number > max) {
    throw new OrderValidationError(`${field} must be an integer between ${min} and ${max}`);
  }
  return number;
}

function artworkPosition(value: unknown) {
  if (value == null) return null;
  if (typeof value !== "object") throw new OrderValidationError("artworkPosition must be an object");
  const candidate = value as Record<string, unknown>;
  const result = { x: Number(candidate.x), y: Number(candidate.y), width: Number(candidate.width), height: Number(candidate.height) };
  if (Object.values(result).some((n) => !Number.isFinite(n))) throw new OrderValidationError("artworkPosition contains invalid values");
  if (result.width <= 0 || result.height <= 0 || result.width > 1000 || result.height > 1000) {
    throw new OrderValidationError("artworkPosition has invalid dimensions");
  }
  return result;
}

export function validateCreateOrder(body: CreateOrderInput): ValidatedOrderInput {
  const garment = cleanString(body.garment, "garment", true)!;
  const color = cleanString(body.color, "color", true)!;
  const size = cleanString(body.size, "size", true)!;
  const printSize = cleanString(body.printSize, "printSize", true)!;
  const deliveryMethod = cleanString(body.deliveryMethod, "deliveryMethod", true)!;
  const deliverySpeedRaw = cleanString(body.deliverySpeed, "deliverySpeed");

  if (!PRODUCTS.some((product) => product.id === garment)) throw new OrderValidationError("Invalid garment");
  if (!COLORS.some((item) => item.name === color)) throw new OrderValidationError("Invalid color");
  if (!SIZES.includes(size)) throw new OrderValidationError("Invalid size");
  if (!PRINT_SIZES.some((item) => item.id === printSize)) throw new OrderValidationError("Invalid printSize");
  if (deliveryMethod !== "delivery" && deliveryMethod !== "pickup") throw new OrderValidationError("deliveryMethod must be delivery or pickup");
  if (deliveryMethod === "delivery" && deliverySpeedRaw !== "normal" && deliverySpeedRaw !== "express") throw new OrderValidationError("deliverySpeed must be normal or express for delivery orders");
  if (deliveryMethod === "pickup" && deliverySpeedRaw) throw new OrderValidationError("deliverySpeed is not used for pickup orders");

  const clothingQty = positiveInt(body.clothingQty ?? 1, "clothingQty");
  const designQty = positiveInt(body.designQty ?? 1, "designQty");
  const pickupPerson = cleanString(body.pickupPerson, "pickupPerson");
  const customerName = cleanString(body.customerName, "customerName");
  const customerPhone = cleanString(body.customerPhone, "customerPhone");
  const customerAddress = cleanString(body.customerAddress, "customerAddress");
  const customerCity = cleanString(body.customerCity, "customerCity");
  const customerPin = cleanString(body.customerPin, "customerPin");
  const artworkUrl = cleanString(body.artworkUrl, "artworkUrl");
  const position = artworkPosition(body.artworkPosition);

  if (artworkUrl && artworkUrl.length > MAX_ARTWORK_URL) throw new OrderValidationError("artworkUrl is too long");
  if (artworkUrl && !/^\/(?:uploads)\/[A-Za-z0-9._-]+$/.test(artworkUrl)) throw new OrderValidationError("Invalid artworkUrl");

  if (deliveryMethod === "pickup") {
    if (!pickupPerson || !PICKUP_PERSONS.some((person) => person.id === pickupPerson)) throw new OrderValidationError("A valid pickupPerson is required for pickup orders");
  } else if (!customerName || !customerPhone || !customerAddress || !customerCity || !customerPin) {
    throw new OrderValidationError("Name, phone, address, city and PIN are required for delivery");
  }

  if (customerPhone && !/^\+?[0-9 ()-]{7,20}$/.test(customerPhone)) throw new OrderValidationError("Invalid customerPhone");
  if (customerPin && !/^\d{4,10}$/.test(customerPin)) throw new OrderValidationError("Invalid customerPin");

  const deliveryOption = deliveryMethod === "delivery" ? getDeliveryOption(deliverySpeedRaw!) : null;
  if (deliveryMethod === "delivery" && !deliveryOption) throw new OrderValidationError("Delivery option is not configured");

  return {
    garment, color, size, artworkUrl, artworkPosition: position, printSize, clothingQty, designQty,
    deliveryMethod: deliveryMethod as "delivery" | "pickup",
    deliverySpeed: deliveryOption?.id ?? null,
    deliveryFee: deliveryOption?.fee ?? 0,
    deliveryEtaDays: deliveryOption?.etaDays ?? null,
    pickupPerson: deliveryMethod === "pickup" ? pickupPerson : null,
    customerName, customerPhone,
    customerAddress: deliveryMethod === "delivery" ? customerAddress : null,
    customerCity: deliveryMethod === "delivery" ? customerCity : null,
    customerPin: deliveryMethod === "delivery" ? customerPin : null,
    totalAmount: calculateTotal(garment, printSize, clothingQty, designQty) + (deliveryOption?.fee ?? 0),
  };
}

export function validateStatus(value: unknown): OrderStatus {
  if (typeof value !== "string" || !ORDER_STATUSES.includes(value as OrderStatus)) throw new OrderValidationError("Invalid order status");
  return value as OrderStatus;
}

export function validatePaymentStatus(value: unknown): PaymentStatus {
  if (typeof value !== "string" || !PAYMENT_STATUSES.includes(value as PaymentStatus)) throw new OrderValidationError("Invalid payment status");
  return value as PaymentStatus;
}
