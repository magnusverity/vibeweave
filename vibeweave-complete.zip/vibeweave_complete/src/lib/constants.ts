export const PRODUCTS = [
  {
    id: "round-neck",
    name: "Pure Cotton Round Neck T-Shirt",
    shortName: "Round Neck",
    label: "01",
    category: "tee",
    basePrice: 550,
    image: "https://images.pexels.com/photos/30710033/pexels-photo-30710033.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    heroImage: "https://images.pexels.com/photos/37704848/pexels-photo-37704848.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    description: "100% pure cotton. Ribbed collar. Comfortable regular fit.",
    tag: "BESTSELLER",
  },
  {
    id: "polo",
    name: "Pure Cotton Polo T-Shirt",
    shortName: "Polo",
    label: "02",
    category: "polo",
    basePrice: 560,
    image: "https://images.pexels.com/photos/24509673/pexels-photo-24509673.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    heroImage: "https://images.pexels.com/photos/20226025/pexels-photo-20226025.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    description: "Classic polo collar. Button placket. Premium cotton weave.",
    tag: "CLASSIC",
  },
  {
    id: "oversized",
    name: "Pure Cotton Oversized T-Shirt",
    shortName: "Oversized Tee",
    label: "03",
    category: "tee",
    basePrice: 600,
    image: "https://images.pexels.com/photos/18584221/pexels-photo-18584221.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    heroImage: "https://images.pexels.com/photos/30257616/pexels-photo-30257616.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    description: "Dropped shoulders. Relaxed silhouette. Streetwear essential.",
    tag: "STREET PICK",
  },
  {
    id: "kids",
    name: "Kid's Cotton T-Shirt",
    shortName: "Kids Tee",
    label: "04",
    category: "kids",
    basePrice: 400,
    image: "https://images.pexels.com/photos/36317737/pexels-photo-36317737.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    heroImage: "https://images.pexels.com/photos/9587495/pexels-photo-9587495.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    description: "Soft cotton. Kid-friendly fit. Machine washable.",
    tag: "KIDS",
  },
  {
    id: "hoodie",
    name: "Cotton Hoodie",
    shortName: "Hoodie",
    label: "05",
    category: "hoodie",
    basePrice: 700,
    image: "https://images.pexels.com/photos/4118957/pexels-photo-4118957.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    heroImage: "https://images.pexels.com/photos/7263105/pexels-photo-7263105.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    description: "Heavy cotton blend. Kangaroo pocket. Adjustable hood.",
    tag: "WINTER READY",
  },
];

export const COLORS = [
  { name: "Blue", hex: "#3B6FD4", label: "Blue" },
  { name: "Red", hex: "#8B1A1A", label: "Red" },
  { name: "Dark Grey", hex: "#2C2C2C", label: "Dark Grey" },
  { name: "Light Cyan", hex: "#A8DFDC", label: "Light Cyan" },
  { name: "Pink", hex: "#E8A0B0", label: "Pink" },
  { name: "Mint Green", hex: "#5EC4A8", label: "Mint Green" },
  { name: "Coral", hex: "#E87060", label: "Coral" },
  { name: "Bright Red", hex: "#E02020", label: "Bright Red" },
  { name: "Yellow", hex: "#F0B820", label: "Yellow" },
  { name: "Black", hex: "#0D0D0D", label: "Black" },
  { name: "Light Grey", hex: "#BEBEBE", label: "Light Grey" },
  { name: "Off-White", hex: "#EDE8DF", label: "Off-White" },
];

export const SIZES = ["M", "L", "XL", "2XL", "XXL"];

export const PRINT_SIZES = [
  { id: "A2", label: "A2", description: "Extra Large", scale: 1.4, priceAdd: 110 },
  { id: "A3", label: "A3", description: "Large", scale: 1.1, priceAdd: 80 },
  { id: "A4", label: "A4", description: "Standard", scale: 0.85, priceAdd: 50 },
  { id: "A7", label: "A7", description: "Small", scale: 0.5, priceAdd: 30 },
];

export const PICKUP_PERSONS = [
  { id: "srijit", name: "Srijit", description: "Available Mon–Sat" },
  { id: "ayaan", name: "Ayaan", description: "Available Mon–Fri" },
];

export function getProductById(id: string) {
  return PRODUCTS.find((p) => p.id === id);
}

export function getColorByName(name: string) {
  return COLORS.find((c) => c.name === name);
}

export function getPrintSizeById(id: string) {
  return PRINT_SIZES.find((p) => p.id === id);
}

export function calculateTotal(
  garmentId: string,
  printSizeId: string,
  clothingQty: number,
  designQty: number
): number {
  const product = getProductById(garmentId);
  const printSize = getPrintSizeById(printSizeId);
  if (!product) return 0;
  const base = product.basePrice * clothingQty;
  const design = (printSize?.priceAdd ?? 60) * designQty;
  return base + design;
}
