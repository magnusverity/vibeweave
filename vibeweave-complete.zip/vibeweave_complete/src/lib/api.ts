import { NextResponse } from "next/server";

export function jsonError(message: string, status = 400, details?: unknown) {
  return NextResponse.json({ success: false, error: message, ...(details ? { details } : {}) }, { status });
}

export function isAdminRequest(req: Request) {
  const configured = process.env.ADMIN_API_KEY;
  if (!configured) return false;
  const supplied = req.headers.get("x-admin-key");
  return Boolean(supplied && supplied === configured);
}
