"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isCreate = pathname?.startsWith("/create") || pathname?.startsWith("/studio");

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled || isCreate
          ? "bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#E0DDD8]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="font-editorial font-bold text-xl tracking-[-0.04em] text-[#0D0D0D]">
          VIBEWEAVE
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8 text-[13px] font-medium tracking-[0.08em] uppercase">
          <Link
            href="/"
            className={`transition-colors ${pathname === "/" ? "text-[#0D0D0D]" : "text-[#7A7672] hover:text-[#0D0D0D]"}`}
          >
            Home
          </Link>
          <Link
            href="/shop"
            className={`transition-colors ${pathname === "/shop" ? "text-[#0D0D0D]" : "text-[#7A7672] hover:text-[#0D0D0D]"}`}
          >
            Shop
          </Link>
          <Link
            href="/studio"
            className={`transition-colors ${pathname?.startsWith("/studio") ? "text-[#0D0D0D]" : "text-[#7A7672] hover:text-[#0D0D0D]"}`}
          >
            Create
          </Link>
          <Link
            href="/account"
            className={`transition-colors ${pathname === "/account" ? "text-[#0D0D0D]" : "text-[#7A7672] hover:text-[#0D0D0D]"}`}
          >
            Account
          </Link>
          <Link
            href="/my-order"
            className={`transition-colors ${pathname === "/my-order" ? "text-[#0D0D0D]" : "text-[#7A7672] hover:text-[#0D0D0D]"}`}
          >
            My Order
          </Link>
        </div>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-4">
          <Link
            href="/studio"
            className="flex items-center gap-2 bg-[#0D0D0D] text-[#FAF8F5] px-5 py-2.5 text-[12px] tracking-[0.1em] uppercase font-medium hover:bg-[#1A1A1A] transition-colors"
          >
            Start Creating
            <span className="inline-block transition-transform group-hover:translate-x-1">→</span>
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Menu"
        >
          <span className={`block w-6 h-px bg-[#0D0D0D] transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
          <span className={`block w-6 h-px bg-[#0D0D0D] transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
          <span className={`block w-6 h-px bg-[#0D0D0D] transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-500 bg-[#FAF8F5] ${
          menuOpen ? "max-h-80 border-b border-[#E0DDD8]" : "max-h-0"
        }`}
      >
        <div className="px-6 py-6 flex flex-col gap-5">
          {[
            { href: "/", label: "Home" },
            { href: "/shop", label: "Shop" },
            { href: "/studio", label: "Create" },
            { href: "/my-order", label: "My Order" },
            { href: "/account", label: "Account" },
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMenuOpen(false)}
              className="text-[15px] font-medium tracking-[0.05em] uppercase text-[#0D0D0D]"
            >
              {item.label}
            </Link>
          ))}
          <Link
            href="/studio"
            onClick={() => setMenuOpen(false)}
            className="inline-block bg-[#0D0D0D] text-[#FAF8F5] px-5 py-3 text-[12px] tracking-[0.1em] uppercase font-medium text-center mt-2"
          >
            Start Creating →
          </Link>
        </div>
      </div>
    </nav>
  );
}
