"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import Nav from "@/components/Nav";
import GarmentMockup from "@/components/studio/GarmentMockup";
import { useOrderStore } from "@/store/orderStore";
import { PRODUCTS, COLORS, SIZES, PRINT_SIZES, calculateTotal, getProductById } from "@/lib/constants";

const STEPS = [
  { id: 1, label: "Garment" },
  { id: 2, label: "Colour" },
  { id: 3, label: "Size" },
  { id: 4, label: "Design" },
  { id: 5, label: "Review" },
  { id: 6, label: "Delivery" },
  { id: 7, label: "Payment" },
];

function QuantityControl({ value, onChange, min = 1, max = 100 }: { value: number; onChange: (v: number) => void; min?: number; max?: number }) {
  return (
    <div className="flex items-center gap-0">
      <button
        onClick={() => onChange(Math.max(min, value - 1))}
        className="w-10 h-10 border border-[#E0DDD8] text-[#0D0D0D] text-lg font-light flex items-center justify-center hover:bg-[#F0EDE8] transition-colors"
      >
        −
      </button>
      <div className="w-14 h-10 border-t border-b border-[#E0DDD8] flex items-center justify-center font-editorial font-bold text-[#0D0D0D]">
        {value}
      </div>
      <button
        onClick={() => onChange(Math.min(max, value + 1))}
        className="w-10 h-10 border border-[#E0DDD8] text-[#0D0D0D] text-lg font-light flex items-center justify-center hover:bg-[#F0EDE8] transition-colors"
      >
        +
      </button>
    </div>
  );
}

export default function StudioContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const store = useOrderStore();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [deliveryOptions, setDeliveryOptions] = useState<Array<{ id: string; fee: number; etaDays: number; label?: string }>>([]);
  const [serverTotal, setServerTotal] = useState<number | null>(null);
  const [priceLoading, setPriceLoading] = useState(false);
  const [submitError, setSubmitError] = useState("");

  useEffect(() => {
    fetch("/api/delivery-options")
      .then((r) => r.json())
      .then((data) => { if (data.success) setDeliveryOptions(data.options); })
      .catch(() => {});

    fetch("/api/account/me")
      .then((r) => r.json())
      .then((data) => {
        if (!data.success) return;
        const account = data.account;
        if (account.name && !store.customerName) store.setCustomerName(account.name);
        if (account.phone && !store.customerPhone) store.setCustomerPhone(account.phone);
        if (account.address && !store.customerAddress) store.setCustomerAddress(account.address);
        if (account.city && !store.customerCity) store.setCustomerCity(account.city);
        if (account.pin && !store.customerPin) store.setCustomerPin(account.pin);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!store.garment || !store.printSize) return;
    const controller = new AbortController();
    setPriceLoading(true);
    setServerTotal(null);
    const params = new URLSearchParams({
      garment: store.garment,
      printSize: store.printSize,
      clothingQty: String(store.clothingQty),
      designQty: String(store.designQty),
      deliveryMethod: store.deliveryMethod || "pickup",
      deliverySpeed: store.deliverySpeed || "normal",
    });
    fetch(`/api/pricing?${params.toString()}`, { signal: controller.signal })
      .then((r) => r.json())
      .then((data) => { if (data.success) setServerTotal(data.amount); })
      .catch(() => {})
      .finally(() => setPriceLoading(false));
    return () => controller.abort();
  }, [store.garment, store.printSize, store.clothingQty, store.designQty, store.deliveryMethod, store.deliverySpeed]);

  // Pre-select product from URL
  useEffect(() => {
    const productParam = searchParams.get("product");
    if (productParam && !store.garment) {
      store.setGarment(productParam);
      store.setCurrentStep(2);
    }
  }, []);

  const step = store.currentStep;
  const baseTotal = calculateTotal(store.garment, store.printSize, store.clothingQty, store.designQty);
  const selectedDelivery = deliveryOptions.find((option) => option.id === store.deliverySpeed);
  const total = serverTotal ?? (baseTotal + (store.deliveryMethod === "delivery" ? (selectedDelivery?.fee ?? 0) : 0));
  const product = getProductById(store.garment);

  const goTo = (s: number) => store.setCurrentStep(s);
  const next = () => store.setCurrentStep(Math.min(7, step + 1));
  const prev = () => store.setCurrentStep(Math.max(1, step - 1));

  const handleFileUpload = async (file: File) => {
    if (!file) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (data.success) {
        store.setArtworkUrl(data.url);
      }
    } catch {
      // fail silently
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith("image/")) handleFileUpload(file);
    },
    []
  );

  const handleSubmit = async () => {
    setSubmitting(true);
    setSubmitError("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          garment: store.garment,
          color: store.color,
          size: store.size,
          artworkUrl: store.artworkUrl,
          artworkPosition: store.artworkPosition,
          printSize: store.printSize,
          clothingQty: store.clothingQty,
          designQty: store.designQty,
          deliveryMethod: store.deliveryMethod,
          deliverySpeed: store.deliveryMethod === "delivery" ? store.deliverySpeed : undefined,
          pickupPerson: store.pickupPerson,
          customerName: store.customerName,
          customerPhone: store.customerPhone,
          customerAddress: store.customerAddress,
          customerCity: store.customerCity,
          customerPin: store.customerPin,
        }),
      });
      const data = await res.json();
      if (data.success) {
        store.setOrderId(data.order.id);
        router.push(`/confirmation?id=${data.order.id}`);
      } else {
        setSubmitError(data.error || "Could not create the order.");
      }
    } catch {
      setSubmitError("Could not connect to VibeWeave. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5]">
      <Nav />

      {/* Studio Header */}
      <div className="pt-20 border-b border-[#E0DDD8] bg-[#FAF8F5]">
        <div className="max-w-[1200px] mx-auto px-6 md:px-12 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <span className="text-[11px] tracking-[0.2em] uppercase text-[#7A7672] font-mono block mb-1">
                Custom Studio
              </span>
              <h1
                className="font-editorial font-bold text-[#0D0D0D] leading-none"
                style={{ fontSize: "clamp(24px, 3vw, 36px)", letterSpacing: "-0.03em" }}
              >
                VIBEWEAVE STUDIO
              </h1>
            </div>
            {step > 1 && (
              <div className="text-right">
                <p className="text-[11px] font-mono text-[#7A7672] tracking-wider">TOTAL</p>
                <p className="font-editorial font-bold text-[#0D0D0D] text-2xl">₹{total}</p>
              </div>
            )}
          </div>

          {/* Step indicators */}
          <div className="flex items-center gap-0 overflow-x-auto pb-1">
            {STEPS.map((s, i) => (
              <div key={s.id} className="flex items-center">
                <button
                  onClick={() => step > s.id ? goTo(s.id) : undefined}
                  className={`flex items-center gap-2 px-3 py-2 text-[11px] tracking-[0.08em] uppercase font-mono transition-colors whitespace-nowrap ${
                    step === s.id
                      ? "text-[#0D0D0D] border-b-2 border-[#C8FF00]"
                      : step > s.id
                      ? "text-[#7A7672] cursor-pointer hover:text-[#0D0D0D]"
                      : "text-[#BEBEBE] cursor-default"
                  }`}
                >
                  <span
                    className={`w-5 h-5 flex items-center justify-center text-[10px] border ${
                      step === s.id
                        ? "border-[#C8FF00] bg-[#C8FF00] text-[#0D0D0D]"
                        : step > s.id
                        ? "border-[#0D0D0D] bg-[#0D0D0D] text-[#FAF8F5]"
                        : "border-[#E0DDD8] text-[#BEBEBE]"
                    }`}
                  >
                    {step > s.id ? "✓" : s.id}
                  </span>
                  <span className="hidden sm:inline">{s.label}</span>
                </button>
                {i < STEPS.length - 1 && (
                  <div className={`w-4 h-px mx-1 ${step > s.id ? "bg-[#0D0D0D]" : "bg-[#E0DDD8]"}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Studio Area */}
      <div className="max-w-[1200px] mx-auto px-6 md:px-12 py-8 md:py-12">

        {/* STEP 1: Garment */}
        {step === 1 && (
          <div>
            <h2 className="font-editorial font-bold text-[#0D0D0D] mb-2" style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}>
              CHOOSE YOUR PIECE
            </h2>
            <p className="text-[#7A7672] text-sm mb-10">Select the garment you want to customise.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {PRODUCTS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => { store.setGarment(p.id); next(); }}
                  className={`group text-left relative overflow-hidden transition-all duration-300 ${
                    store.garment === p.id ? "ring-2 ring-[#0D0D0D]" : "hover:ring-1 hover:ring-[#0D0D0D]/30"
                  }`}
                >
                  <div className="aspect-[4/5] relative overflow-hidden bg-[#E8E4DD]">
                    <Image
                      src={p.image}
                      alt={p.name}
                      fill
                      className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
                      sizes="(max-width: 640px) 100vw, (max-width: 1280px) 50vw, 20vw"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/50 to-transparent" />
                    {store.garment === p.id && (
                      <div className="absolute top-3 right-3 w-6 h-6 bg-[#C8FF00] flex items-center justify-center text-[10px] font-bold">
                        ✓
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 p-3">
                      <span className="text-[10px] font-mono text-[#C8FF00] block">{p.tag}</span>
                      <span className="font-editorial font-bold text-[#FAF8F5] text-sm">{p.shortName}</span>
                    </div>
                  </div>
                  <div className="p-3 bg-[#FAF8F5]">
                    <p className="text-[11px] text-[#7A7672] font-mono tracking-wider mb-1">{p.label}</p>
                    <p className="text-[13px] font-medium text-[#0D0D0D] leading-tight">{p.name}</p>
                    <p className="text-[#7A7672] text-sm mt-1 font-editorial font-bold">₹{p.basePrice}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 2: Colour */}
        {step === 2 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16">
            <div>
              <h2 className="font-editorial font-bold text-[#0D0D0D] mb-2" style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}>
                CHOOSE COLOUR
              </h2>
              <p className="text-[#7A7672] text-sm mb-10">Select your base colour. The garment preview updates in real-time.</p>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-4">
                {COLORS.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => store.setColor(c.name)}
                    className="flex flex-col items-center gap-2 group"
                  >
                    <div
                      className={`w-12 h-12 rounded-full border-2 transition-all duration-300 ${
                        store.color === c.name
                          ? "border-[#0D0D0D] scale-110 shadow-lg"
                          : "border-transparent hover:border-[#0D0D0D]/30 hover:scale-105"
                      }`}
                      style={{ backgroundColor: c.hex }}
                    />
                    <span className={`text-[10px] tracking-[0.05em] font-mono leading-tight text-center transition-colors ${store.color === c.name ? "text-[#0D0D0D]" : "text-[#7A7672]"}`}>
                      {c.name}
                    </span>
                  </button>
                ))}
              </div>
              <div className="mt-10 p-4 bg-[#F0EDE8] border-l-2 border-[#0D0D0D]">
                <p className="text-[11px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-1">Selected</p>
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full border border-[#0D0D0D]/10" style={{ backgroundColor: COLORS.find(c => c.name === store.color)?.hex }} />
                  <p className="font-editorial font-bold text-[#0D0D0D] text-lg">{store.color}</p>
                </div>
              </div>
              <div className="flex gap-3 mt-8">
                <button onClick={prev} className="px-6 py-3 border border-[#E0DDD8] text-[12px] tracking-[0.1em] uppercase font-mono text-[#7A7672] hover:text-[#0D0D0D] transition-colors">
                  ← Back
                </button>
                <button onClick={next} className="flex-1 bg-[#0D0D0D] text-[#FAF8F5] py-3 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors">
                  Next: Size →
                </button>
              </div>
            </div>
            <div className="hidden lg:block">
              <GarmentMockup
                garmentId={store.garment}
                color={store.color}
                artworkUrl={null}
                artworkPosition={store.artworkPosition}
                printSize={store.printSize}
                onPositionChange={store.setArtworkPosition}
                onArtworkRemove={() => store.setArtworkUrl(null)}
              />
            </div>
          </div>
        )}

        {/* STEP 3: Size */}
        {step === 3 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16">
            <div>
              <h2 className="font-editorial font-bold text-[#0D0D0D] mb-2" style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}>
                CHOOSE SIZE
              </h2>
              <p className="text-[#7A7672] text-sm mb-10">All garments are true to standard Indian sizing.</p>
              <div className="flex flex-wrap gap-3 mb-10">
                {SIZES.map((s) => (
                  <button
                    key={s}
                    onClick={() => store.setSize(s)}
                    className={`w-16 h-16 text-[15px] font-editorial font-bold border-2 transition-all duration-200 ${
                      store.size === s
                        ? "bg-[#0D0D0D] text-[#FAF8F5] border-[#0D0D0D]"
                        : "bg-transparent text-[#0D0D0D] border-[#E0DDD8] hover:border-[#0D0D0D]"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <button onClick={prev} className="px-6 py-3 border border-[#E0DDD8] text-[12px] tracking-[0.1em] uppercase font-mono text-[#7A7672] hover:text-[#0D0D0D] transition-colors">
                  ← Back
                </button>
                <button onClick={next} className="flex-1 bg-[#0D0D0D] text-[#FAF8F5] py-3 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors">
                  Next: Upload Design →
                </button>
              </div>
            </div>
            <div className="hidden lg:block">
              <GarmentMockup
                garmentId={store.garment}
                color={store.color}
                artworkUrl={null}
                artworkPosition={store.artworkPosition}
                printSize={store.printSize}
                onPositionChange={store.setArtworkPosition}
                onArtworkRemove={() => store.setArtworkUrl(null)}
              />
            </div>
          </div>
        )}

        {/* STEP 4: Design */}
        {step === 4 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16">
            <div>
              <h2 className="font-editorial font-bold text-[#0D0D0D] mb-2" style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}>
                YOUR DESIGN
              </h2>
              <p className="text-[#7A7672] text-sm mb-8">Upload your artwork, choose print size, and set quantities.</p>

              {/* Upload */}
              <div className="mb-8">
                <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-3">Artwork Upload</p>
                {store.artworkUrl ? (
                  <div className="flex items-center gap-4 p-4 bg-[#F0EDE8] border border-[#E0DDD8]">
                    <Image src={store.artworkUrl} alt="Artwork" width={60} height={60} className="object-contain bg-white" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-[#0D0D0D]">Artwork uploaded</p>
                      <p className="text-[11px] text-[#7A7672]">Drag on the preview to reposition</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="text-[11px] tracking-[0.1em] uppercase font-mono text-[#7A7672] border-b border-[#7A7672]/40 hover:text-[#0D0D0D] transition-colors"
                      >
                        Replace
                      </button>
                      <button
                        onClick={() => store.setArtworkUrl(null)}
                        className="text-[11px] tracking-[0.1em] uppercase font-mono text-red-500 border-b border-red-300 hover:text-red-700 transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    className="border-2 border-dashed border-[#E0DDD8] p-10 text-center cursor-pointer hover:border-[#7A7672] transition-colors"
                    onDrop={handleDrop}
                    onDragOver={(e) => e.preventDefault()}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    {uploading ? (
                      <div className="space-y-2">
                        <div className="w-8 h-8 border-2 border-[#0D0D0D] border-t-transparent rounded-full animate-spin mx-auto" />
                        <p className="text-[12px] text-[#7A7672] font-mono">Uploading...</p>
                      </div>
                    ) : (
                      <>
                        <div className="text-3xl mb-3">↑</div>
                        <p className="font-medium text-[#0D0D0D] mb-1">Drop your artwork here</p>
                        <p className="text-[12px] text-[#7A7672]">PNG, JPG, SVG — any format</p>
                      </>
                    )}
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(file);
                  }}
                />
              </div>

              {/* Print Size */}
              <div className="mb-8">
                <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-3">Print Size</p>
                <div className="grid grid-cols-4 gap-2">
                  {PRINT_SIZES.map((ps) => (
                    <button
                      key={ps.id}
                      onClick={() => store.setPrintSize(ps.id)}
                      className={`py-3 text-center border-2 transition-all duration-200 ${
                        store.printSize === ps.id
                          ? "border-[#0D0D0D] bg-[#0D0D0D] text-[#FAF8F5]"
                          : "border-[#E0DDD8] text-[#0D0D0D] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <p className="font-editorial font-bold text-base">{ps.label}</p>
                      <p className={`text-[10px] font-mono mt-0.5 ${store.printSize === ps.id ? "text-[#FAF8F5]/70" : "text-[#7A7672]"}`}>
                        {ps.description}
                      </p>
                      <p className={`text-[10px] font-mono mt-0.5 ${store.printSize === ps.id ? "text-[#C8FF00]" : "text-[#7A7672]"}`}>
                        +₹{ps.priceAdd}
                      </p>
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-[#7A7672] font-mono mt-3">For special requests: @vibeweave.</p>
              </div>

              {/* Quantities */}
              <div className="mb-8 grid grid-cols-2 gap-6">
                <div>
                  <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-3">Clothing Qty</p>
                  <QuantityControl value={store.clothingQty} onChange={store.setClothingQty} />
                </div>
                <div>
                  <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-3">Design Qty</p>
                  <QuantityControl value={store.designQty} onChange={store.setDesignQty} />
                </div>
              </div>

              <div className="flex gap-3">
                <button onClick={prev} className="px-6 py-3 border border-[#E0DDD8] text-[12px] tracking-[0.1em] uppercase font-mono text-[#7A7672] hover:text-[#0D0D0D] transition-colors">
                  ← Back
                </button>
                <button onClick={next} className="flex-1 bg-[#0D0D0D] text-[#FAF8F5] py-3 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors">
                  Next: Review →
                </button>
              </div>
            </div>

            {/* Live preview */}
            <div>
              <p className="text-[11px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-3">Live Preview — drag artwork to reposition</p>
              <GarmentMockup
                garmentId={store.garment}
                color={store.color}
                artworkUrl={store.artworkUrl}
                artworkPosition={store.artworkPosition}
                printSize={store.printSize}
                onPositionChange={store.setArtworkPosition}
                onArtworkRemove={() => store.setArtworkUrl(null)}
              />
            </div>
          </div>
        )}

        {/* STEP 5: Review */}
        {step === 5 && (
          <div className="max-w-3xl">
            <h2 className="font-editorial font-bold text-[#0D0D0D] mb-2" style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}>
              YOUR VIBE
            </h2>
            <p className="text-[#7A7672] text-sm mb-10">Review your order before proceeding.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
              {/* Mockup */}
              <GarmentMockup
                garmentId={store.garment}
                color={store.color}
                artworkUrl={store.artworkUrl}
                artworkPosition={store.artworkPosition}
                printSize={store.printSize}
                onPositionChange={store.setArtworkPosition}
                onArtworkRemove={() => store.setArtworkUrl(null)}
              />

              {/* Details */}
              <div>
                {[
                  { label: "Garment", value: product?.name ?? "—", step: 1 },
                  { label: "Colour", value: store.color, step: 2 },
                  { label: "Size", value: store.size, step: 3 },
                  { label: "Design", value: store.artworkUrl ? "Uploaded" : "No artwork", step: 4 },
                  { label: "Print Size", value: store.printSize, step: 4 },
                  { label: "Clothing Qty", value: `×${store.clothingQty}`, step: 4 },
                  { label: "Design Qty", value: `×${store.designQty}`, step: 4 },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between py-3 border-b border-[#E0DDD8]">
                    <span className="text-[11px] tracking-[0.1em] uppercase text-[#7A7672] font-mono">{item.label}</span>
                    <div className="flex items-center gap-4">
                      <span className="font-medium text-[#0D0D0D] text-sm">{item.value}</span>
                      <button
                        onClick={() => goTo(item.step)}
                        className="text-[10px] tracking-[0.1em] uppercase font-mono text-[#7A7672] border-b border-[#7A7672]/30 hover:text-[#0D0D0D] transition-colors"
                      >
                        Edit
                      </button>
                    </div>
                  </div>
                ))}

                <div className="mt-6 p-4 bg-[#F0EDE8]">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono">Total</span>
                    <span className="font-editorial font-bold text-[#0D0D0D] text-2xl">₹{total}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button onClick={prev} className="px-6 py-3 border border-[#E0DDD8] text-[12px] tracking-[0.1em] uppercase font-mono text-[#7A7672] hover:text-[#0D0D0D] transition-colors">
                ← Back
              </button>
              <button onClick={next} className="flex-1 bg-[#0D0D0D] text-[#FAF8F5] py-4 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors">
                Next: Delivery →
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: Delivery */}
        {step === 6 && (
          <div className="max-w-2xl">
            <h2 className="font-editorial font-bold text-[#0D0D0D] mb-2" style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}>
              HOW DO YOU WANT IT?
            </h2>
            <p className="text-[#7A7672] text-sm mb-10">Choose pickup, normal delivery, or express delivery.</p>

            {/* Method */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {[
                { id: "delivery", label: "Deliver to Me", icon: "📦", desc: "We'll ship it to your address." },
                { id: "pickup", label: "Pick Up", icon: "🤝", desc: "Collect from Srijit or Ayaan." },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => store.setDeliveryMethod(m.id)}
                  className={`p-6 text-left border-2 transition-all ${
                    store.deliveryMethod === m.id
                      ? "border-[#0D0D0D] bg-[#0D0D0D] text-[#FAF8F5]"
                      : "border-[#E0DDD8] hover:border-[#0D0D0D] bg-[#FAF8F5] text-[#0D0D0D]"
                  }`}
                >
                  <div className="text-2xl mb-3">{m.icon}</div>
                  <p className="font-editorial font-bold text-base mb-1" style={{ letterSpacing: "-0.02em" }}>{m.label}</p>
                  <p className={`text-[12px] ${store.deliveryMethod === m.id ? "text-[#FAF8F5]/70" : "text-[#7A7672]"}`}>{m.desc}</p>
                </button>
              ))}
            </div>

            {store.deliveryMethod === "delivery" && (
              <div className="mb-8">
                <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-4">Delivery Speed</p>
                <div className="grid grid-cols-2 gap-4">
                  {deliveryOptions.map((option) => ({ id: option.id, label: option.id === "express" ? "Express" : "Normal", desc: option.fee ? `₹${option.fee} • ${option.etaDays} days` : `${option.etaDays} days` })).map((option) => (
                    <button key={option.id} onClick={() => store.setDeliverySpeed(option.id)} className={`p-5 text-left border-2 transition-all ${store.deliverySpeed === option.id ? "border-[#0D0D0D] bg-[#0D0D0D] text-[#FAF8F5]" : "border-[#E0DDD8] hover:border-[#0D0D0D]"}`}>
                      <p className="font-editorial font-bold text-lg mb-1">{option.label}</p>
                      <p className={`text-[11px] ${store.deliverySpeed === option.id ? "text-[#FAF8F5]/60" : "text-[#7A7672]"}`}>{option.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Delivery form */}
            {store.deliveryMethod === "delivery" && (
              <div className="space-y-4 mb-8">
                {[
                  { label: "Name", key: "customerName", type: "text", value: store.customerName, set: store.setCustomerName, placeholder: "Your full name" },
                  { label: "Phone", key: "customerPhone", type: "tel", value: store.customerPhone, set: store.setCustomerPhone, placeholder: "+91 98765 43210" },
                  { label: "Address", key: "customerAddress", type: "text", value: store.customerAddress, set: store.setCustomerAddress, placeholder: "Street address" },
                  { label: "City", key: "customerCity", type: "text", value: store.customerCity, set: store.setCustomerCity, placeholder: "City" },
                  { label: "PIN Code", key: "customerPin", type: "text", value: store.customerPin, set: store.setCustomerPin, placeholder: "6-digit PIN" },
                ].map((field) => (
                  <div key={field.key}>
                    <label className="block text-[11px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-2">{field.label}</label>
                    <input
                      type={field.type}
                      value={field.value}
                      onChange={(e) => field.set(e.target.value)}
                      placeholder={field.placeholder}
                      className="w-full border border-[#E0DDD8] bg-[#FAF8F5] px-4 py-3 text-[#0D0D0D] text-sm focus:outline-none focus:border-[#0D0D0D] transition-colors"
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Pickup selection */}
            {store.deliveryMethod === "pickup" && (
              <div className="mb-8">
                <p className="text-[12px] tracking-[0.1em] uppercase text-[#7A7672] font-mono mb-4">Pick Up From</p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { id: "srijit", name: "SRIJIT", desc: "Available Mon–Sat" },
                    { id: "ayaan", name: "AYAAN", desc: "Available Mon–Fri" },
                  ].map((person) => (
                    <button
                      key={person.id}
                      onClick={() => store.setPickupPerson(person.id)}
                      className={`p-6 text-left border-2 transition-all ${
                        store.pickupPerson === person.id
                          ? "border-[#0D0D0D] bg-[#0D0D0D] text-[#FAF8F5]"
                          : "border-[#E0DDD8] hover:border-[#0D0D0D]"
                      }`}
                    >
                      <p className="font-editorial font-bold text-xl mb-1" style={{ letterSpacing: "-0.03em" }}>{person.name}</p>
                      <p className={`text-[11px] font-mono ${store.pickupPerson === person.id ? "text-[#FAF8F5]/60" : "text-[#7A7672]"}`}>{person.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={prev} className="px-6 py-3 border border-[#E0DDD8] text-[12px] tracking-[0.1em] uppercase font-mono text-[#7A7672] hover:text-[#0D0D0D] transition-colors">
                ← Back
              </button>
              <button
                onClick={next}
                disabled={
                  !store.deliveryMethod ||
                  (store.deliveryMethod === "delivery" && (!store.customerName || !store.customerPhone || !store.customerAddress || !store.customerCity || !store.customerPin)) ||
                  (store.deliveryMethod === "pickup" && !store.pickupPerson)
                }
                className="flex-1 bg-[#0D0D0D] text-[#FAF8F5] py-4 text-[12px] tracking-[0.1em] uppercase font-bold hover:bg-[#1A1A1A] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Next: Payment →
              </button>
            </div>
          </div>
        )}

        {/* STEP 7: Payment */}
        {step === 7 && (
          <div className="max-w-3xl">
            <h2 className="font-editorial font-bold text-[#0D0D0D] mb-2" style={{ fontSize: "clamp(28px, 4vw, 48px)", letterSpacing: "-0.03em" }}>
              READY TO WEAR IT?
            </h2>
            <p className="text-[#7A7672] text-sm mb-10">Place the order, then pay securely by UPI using the provided QR. Your payment is confirmed by the VibeWeave team after verification.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              {/* Preview */}
              <GarmentMockup
                garmentId={store.garment}
                color={store.color}
                artworkUrl={store.artworkUrl}
                artworkPosition={store.artworkPosition}
                printSize={store.printSize}
                onPositionChange={store.setArtworkPosition}
                onArtworkRemove={() => store.setArtworkUrl(null)}
              />

              {/* Final summary */}
              <div>
                <div className="space-y-0">
                  {[
                    { label: "Garment", value: product?.name ?? "—" },
                    { label: "Colour", value: store.color },
                    { label: "Size", value: store.size },
                    { label: "Print Size", value: store.printSize },
                    { label: "Clothing ×", value: store.clothingQty.toString() },
                    { label: "Design ×", value: store.designQty.toString() },
                    {
                      label: "Delivery",
                      value:
                        store.deliveryMethod === "pickup"
                          ? `Pickup — ${store.pickupPerson ? store.pickupPerson.charAt(0).toUpperCase() + store.pickupPerson.slice(1) : ""}`
                          : `${store.deliverySpeed === "express" ? "Express" : "Normal"} delivery to ${store.customerCity || store.customerAddress || "address"}`,
                    },
                  ].map((item) => (
                    <div key={item.label} className="flex justify-between py-2.5 border-b border-[#E0DDD8]">
                      <span className="text-[11px] tracking-[0.08em] uppercase text-[#7A7672] font-mono">{item.label}</span>
                      <span className="text-sm font-medium text-[#0D0D0D]">{item.value}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-5 bg-[#0D0D0D] text-[#FAF8F5]">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] tracking-[0.1em] uppercase font-mono text-[#FAF8F5]/60">Total Amount</span>
                    <span className="font-editorial font-bold text-3xl text-[#C8FF00]">₹{total}</span>
                  </div>
                  <p className="text-[10px] text-[#FAF8F5]/40 font-mono">includes all taxes</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button onClick={prev} className="px-6 py-3 border border-[#E0DDD8] text-[12px] tracking-[0.1em] uppercase font-mono text-[#7A7672] hover:text-[#0D0D0D] transition-colors">
                ← Back
              </button>
              {submitError && <p className="text-sm text-red-700 mb-3">{submitError}</p>}
              <button
                onClick={handleSubmit}
                disabled={submitting || priceLoading}
                className="flex-1 bg-[#C8FF00] text-[#0D0D0D] py-5 text-[14px] tracking-[0.15em] uppercase font-bold hover:bg-[#E8FF6A] transition-colors disabled:opacity-50"
              >
                {submitting ? "Creating order..." : priceLoading ? "Checking total..." : "PLACE ORDER →"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
