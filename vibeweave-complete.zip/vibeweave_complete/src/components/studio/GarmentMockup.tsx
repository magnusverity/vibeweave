"use client";
import { useRef, useState, useCallback } from "react";
import Image from "next/image";
import { COLORS, PRINT_SIZES } from "@/lib/constants";
import type { ArtworkPosition } from "@/store/orderStore";

interface GarmentMockupProps {
  garmentId: string;
  color: string;
  artworkUrl: string | null;
  artworkPosition: ArtworkPosition;
  printSize: string;
  onPositionChange: (pos: ArtworkPosition) => void;
  onArtworkRemove: () => void;
}

const GARMENT_SVGS: Record<string, string> = {
  "round-neck": `<svg viewBox="0 0 300 360" xmlns="http://www.w3.org/2000/svg">
    <path d="M 90 20 C 90 20 100 10 150 10 C 200 10 210 20 210 20 L 270 60 L 250 90 L 225 75 L 225 340 L 75 340 L 75 75 L 50 90 L 30 60 Z" fill="FILL_COLOR" stroke="#00000022" stroke-width="1"/>
    <path d="M 90 20 C 90 20 100 45 150 45 C 200 45 210 20 210 20" fill="none" stroke="#00000033" stroke-width="1.5"/>
    <path d="M 75 75 L 75 340 L 225 340 L 225 75" fill="none" stroke="#00000011" stroke-width="1"/>
    <line x1="150" y1="45" x2="150" y2="340" stroke="#00000008" stroke-width="1"/>
    <path d="M 75 200 Q 80 205 75 210" fill="none" stroke="#00000015" stroke-width="1"/>
    <path d="M 225 200 Q 220 205 225 210" fill="none" stroke="#00000015" stroke-width="1"/>
  </svg>`,
  polo: `<svg viewBox="0 0 300 360" xmlns="http://www.w3.org/2000/svg">
    <path d="M 90 20 C 90 20 95 15 150 12 C 205 15 210 20 210 20 L 270 60 L 250 90 L 225 75 L 225 340 L 75 340 L 75 75 L 50 90 L 30 60 Z" fill="FILL_COLOR" stroke="#00000022" stroke-width="1"/>
    <path d="M 90 20 L 130 35 L 130 65 L 150 68 L 170 65 L 170 35 L 210 20" fill="none" stroke="#00000033" stroke-width="1.5"/>
    <rect x="145" y="35" width="10" height="4" rx="1" fill="#00000022"/>
    <rect x="145" y="44" width="10" height="4" rx="1" fill="#00000022"/>
    <rect x="145" y="53" width="10" height="4" rx="1" fill="#00000022"/>
    <path d="M 130 22 L 130 35 M 170 22 L 170 35" stroke="#00000022" stroke-width="1"/>
    <line x1="150" y1="68" x2="150" y2="340" stroke="#00000008" stroke-width="1"/>
  </svg>`,
  oversized: `<svg viewBox="0 0 340 360" xmlns="http://www.w3.org/2000/svg">
    <path d="M 100 25 C 100 25 110 15 170 12 C 230 15 240 25 240 25 L 320 75 L 290 110 L 255 90 L 255 340 L 85 340 L 85 90 L 50 110 L 20 75 Z" fill="FILL_COLOR" stroke="#00000022" stroke-width="1"/>
    <path d="M 100 25 C 100 25 110 50 170 50 C 230 50 240 25 240 25" fill="none" stroke="#00000033" stroke-width="1.5"/>
    <line x1="170" y1="50" x2="170" y2="340" stroke="#00000008" stroke-width="1"/>
    <path d="M 85 220 Q 90 226 85 232" fill="none" stroke="#00000015" stroke-width="1"/>
    <path d="M 255 220 Q 250 226 255 232" fill="none" stroke="#00000015" stroke-width="1"/>
  </svg>`,
  kids: `<svg viewBox="0 0 240 300" xmlns="http://www.w3.org/2000/svg">
    <path d="M 72 18 C 72 18 80 8 120 8 C 160 8 168 18 168 18 L 215 50 L 198 72 L 180 60 L 180 280 L 60 280 L 60 60 L 42 72 L 25 50 Z" fill="FILL_COLOR" stroke="#00000022" stroke-width="1"/>
    <path d="M 72 18 C 72 18 80 38 120 38 C 160 38 168 18 168 18" fill="none" stroke="#00000033" stroke-width="1.5"/>
    <line x1="120" y1="38" x2="120" y2="280" stroke="#00000008" stroke-width="1"/>
  </svg>`,
  hoodie: `<svg viewBox="0 0 320 380" xmlns="http://www.w3.org/2000/svg">
    <path d="M 95 35 C 95 35 80 20 160 15 C 240 20 225 35 225 35 L 295 80 L 270 115 L 240 95 L 240 360 L 80 360 L 80 95 L 50 115 L 25 80 Z" fill="FILL_COLOR" stroke="#00000022" stroke-width="1.5"/>
    <path d="M 95 35 C 95 35 100 10 160 8 C 220 10 225 35 225 35 L 200 60 C 200 60 185 80 160 82 C 135 80 120 60 120 60 Z" fill="FILL_COLOR" stroke="#00000033" stroke-width="1.5"/>
    <line x1="160" y1="82" x2="160" y2="360" stroke="#00000008" stroke-width="1"/>
    <rect x="140" y="280" width="40" height="55" rx="3" fill="#00000015"/>
    <path d="M 80 180 L 240 180" stroke="#00000010" stroke-width="1"/>
    <path d="M 95 35 L 120 60 M 225 35 L 200 60" stroke="#00000022" stroke-width="1"/>
  </svg>`,
};

function getSvgDataUrl(garmentId: string, colorHex: string): string {
  const svg = GARMENT_SVGS[garmentId] ?? GARMENT_SVGS["round-neck"];
  const filled = svg.replace(/FILL_COLOR/g, colorHex);
  const encoded = encodeURIComponent(filled);
  return `data:image/svg+xml;charset=utf-8,${encoded}`;
}

function getPrintDimensions(printSizeId: string): { w: number; h: number } {
  const map: Record<string, { w: number; h: number }> = {
    A2: { w: 180, h: 254 },
    A3: { w: 140, h: 198 },
    A4: { w: 110, h: 155 },
    A7: { w: 60, h: 85 },
  };
  return map[printSizeId] ?? map["A4"];
}

export default function GarmentMockup({
  garmentId,
  color,
  artworkUrl,
  artworkPosition,
  printSize,
  onPositionChange,
  onArtworkRemove,
}: GarmentMockupProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const dragStart = useRef({ mx: 0, my: 0, ox: 0, oy: 0 });
  const resizing = useRef(false);
  const resizeStart = useRef({ mx: 0, size: 0 });

  const colorObj = COLORS.find((c) => c.name === color);
  const colorHex = colorObj?.hex ?? "#EDE8DF";
  const svgUrl = getSvgDataUrl(garmentId, colorHex);
  const printDims = getPrintDimensions(printSize);

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dragging.current = true;
      dragStart.current = {
        mx: e.clientX,
        my: e.clientY,
        ox: artworkPosition.x,
        oy: artworkPosition.y,
      };
      const onMove = (ev: MouseEvent) => {
        if (!dragging.current || !containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const dx = ((ev.clientX - dragStart.current.mx) / rect.width) * 100;
        const dy = ((ev.clientY - dragStart.current.my) / rect.height) * 100;
        onPositionChange({
          ...artworkPosition,
          x: Math.max(5, Math.min(95, dragStart.current.ox + dx)),
          y: Math.max(5, Math.min(85, dragStart.current.oy + dy)),
        });
      };
      const onUp = () => {
        dragging.current = false;
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    },
    [artworkPosition, onPositionChange]
  );

  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      e.preventDefault();
      const t = e.touches[0];
      dragging.current = true;
      dragStart.current = {
        mx: t.clientX,
        my: t.clientY,
        ox: artworkPosition.x,
        oy: artworkPosition.y,
      };
      const onMove = (ev: TouchEvent) => {
        if (!dragging.current || !containerRef.current) return;
        const touch = ev.touches[0];
        const rect = containerRef.current.getBoundingClientRect();
        const dx = ((touch.clientX - dragStart.current.mx) / rect.width) * 100;
        const dy = ((touch.clientY - dragStart.current.my) / rect.height) * 100;
        onPositionChange({
          ...artworkPosition,
          x: Math.max(5, Math.min(95, dragStart.current.ox + dx)),
          y: Math.max(5, Math.min(85, dragStart.current.oy + dy)),
        });
      };
      const onEnd = () => {
        dragging.current = false;
        window.removeEventListener("touchmove", onMove);
        window.removeEventListener("touchend", onEnd);
      };
      window.addEventListener("touchmove", onMove, { passive: false });
      window.addEventListener("touchend", onEnd);
    },
    [artworkPosition, onPositionChange]
  );

  const handleResizeDown = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      resizing.current = true;
      resizeStart.current = { mx: e.clientX, size: artworkPosition.width };
      const onMove = (ev: MouseEvent) => {
        if (!resizing.current || !containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const dw = ((ev.clientX - resizeStart.current.mx) / rect.width) * 100;
        const newW = Math.max(30, Math.min(80, resizeStart.current.size + dw * 1.5));
        onPositionChange({ ...artworkPosition, width: newW, height: newW });
      };
      const onUp = () => {
        resizing.current = false;
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    },
    [artworkPosition, onPositionChange]
  );

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[3/4] bg-[#F0EDE8] overflow-hidden select-none"
      style={{ touchAction: "none" }}
    >
      {/* Garment SVG */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={svgUrl}
        alt="Garment"
        className="absolute inset-0 w-full h-full object-contain p-6"
        draggable={false}
      />

      {/* Artwork overlay */}
      {artworkUrl && (
        <div
          className="absolute"
          style={{
            left: `${artworkPosition.x}%`,
            top: `${artworkPosition.y}%`,
            width: `${artworkPosition.width}%`,
            height: `${artworkPosition.height}%`,
            transform: "translate(-50%, -50%)",
            cursor: "grab",
          }}
          onMouseDown={handleMouseDown}
          onTouchStart={handleTouchStart}
        >
          <div className="relative w-full h-full border border-dashed border-[#0D0D0D]/30 hover:border-[#0D0D0D]/60 transition-colors">
            <Image
              src={artworkUrl}
              alt="Your artwork"
              fill
              className="object-contain"
              draggable={false}
              sizes="200px"
            />
            {/* Remove button */}
            <button
              className="absolute -top-3 -right-3 w-6 h-6 bg-[#0D0D0D] text-[#FAF8F5] text-xs flex items-center justify-center hover:bg-red-600 transition-colors z-10"
              onMouseDown={(e) => {
                e.stopPropagation();
                onArtworkRemove();
              }}
            >
              ✕
            </button>
            {/* Resize handle */}
            <div
              className="absolute -bottom-2 -right-2 w-5 h-5 bg-[#C8FF00] border border-[#0D0D0D] cursor-se-resize flex items-center justify-center"
              onMouseDown={handleResizeDown}
            >
              <svg width="8" height="8" viewBox="0 0 8 8">
                <path d="M2 8L8 2M5 8L8 5" stroke="#0D0D0D" strokeWidth="1.5" />
              </svg>
            </div>
          </div>
        </div>
      )}

      {/* Print size indicator */}
      {!artworkUrl && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div
            className="border-2 border-dashed border-[#7A7672]/30 flex items-center justify-center"
            style={{ width: `${printDims.w * 0.5}%`, height: `${printDims.h * 0.5}%` }}
          >
            <span className="text-[10px] text-[#7A7672]/60 font-mono tracking-wider">{printSize}</span>
          </div>
        </div>
      )}

      {/* Color label */}
      <div className="absolute bottom-3 left-3">
        <div className="flex items-center gap-2 bg-[#FAF8F5]/80 backdrop-blur-sm px-2 py-1">
          <div
            className="w-3 h-3 rounded-full border border-[#0D0D0D]/10"
            style={{ backgroundColor: colorHex }}
          />
          <span className="text-[10px] font-mono text-[#7A7672] tracking-wider">{color}</span>
        </div>
      </div>
    </div>
  );
}
