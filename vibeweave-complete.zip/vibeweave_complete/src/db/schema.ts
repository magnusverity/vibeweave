import { pgTable, text, integer, timestamp, jsonb, index, uniqueIndex } from "drizzle-orm/pg-core";

export const accounts = pgTable("accounts", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  phone: text("phone"),
  address: text("address"),
  city: text("city"),
  pin: text("pin"),
  tokenBalance: integer("token_balance").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  emailUnique: uniqueIndex("accounts_email_unique").on(table.email),
}));

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  accountId: text("account_id").notNull().references(() => accounts.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({ accountIdx: index("sessions_account_idx").on(table.accountId) }));

export const tokenTransactions = pgTable("token_transactions", {
  id: text("id").primaryKey(),
  accountId: text("account_id").notNull().references(() => accounts.id, { onDelete: "cascade" }),
  amount: integer("amount").notNull(),
  type: text("type").notNull(),
  reason: text("reason").notNull(),
  reference: text("reference"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({ accountIdx: index("token_transactions_account_idx").on(table.accountId), createdIdx: index("token_transactions_created_idx").on(table.createdAt) }));

export const agents = pgTable("agents", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone"),
  address: text("address"),
  availability: text("availability"),
  active: integer("active").notNull().default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: text("id").primaryKey(),
  accountId: text("account_id").references(() => accounts.id, { onDelete: "set null" }),
  garment: text("garment").notNull(),
  color: text("color").notNull(),
  size: text("size").notNull(),
  artworkUrl: text("artwork_url"),
  artworkPosition: jsonb("artwork_position"),
  printSize: text("print_size").notNull(),
  clothingQty: integer("clothing_qty").notNull().default(1),
  designQty: integer("design_qty").notNull().default(1),
  deliveryMethod: text("delivery_method").notNull(),
  deliverySpeed: text("delivery_speed"),
  deliveryFee: integer("delivery_fee").notNull().default(0),
  deliveryEtaDays: integer("delivery_eta_days"),
  pickupPerson: text("pickup_person"),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  customerAddress: text("customer_address"),
  customerCity: text("customer_city"),
  customerPin: text("customer_pin"),
  status: text("status").notNull().default("payment_pending"),
  paymentStatus: text("payment_status").notNull().default("pending"),
  paymentProvider: text("payment_provider"),
  paymentReference: text("payment_reference"),
  paymentProofUrl: text("payment_proof_url"),
  totalAmount: integer("total_amount").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  statusIdx: index("orders_status_idx").on(table.status),
  paymentStatusIdx: index("orders_payment_status_idx").on(table.paymentStatus),
  createdAtIdx: index("orders_created_at_idx").on(table.createdAt),
  accountIdx: index("orders_account_idx").on(table.accountId),
}));

export type Account = typeof accounts.$inferSelect;
export type NewAccount = typeof accounts.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type NewOrder = typeof orders.$inferInsert;
