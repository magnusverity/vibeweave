"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface ArtworkPosition {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface OrderState {
  garment: string;
  color: string;
  size: string;
  artworkUrl: string | null;
  artworkPosition: ArtworkPosition;
  printSize: string;
  clothingQty: number;
  designQty: number;
  deliveryMethod: string;
  deliverySpeed: string;
  pickupPerson: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity: string;
  customerPin: string;
  orderId: string | null;
  currentStep: number;
}

interface OrderActions {
  setGarment: (v: string) => void;
  setColor: (v: string) => void;
  setSize: (v: string) => void;
  setArtworkUrl: (v: string | null) => void;
  setArtworkPosition: (v: ArtworkPosition) => void;
  setPrintSize: (v: string) => void;
  setClothingQty: (v: number) => void;
  setDesignQty: (v: number) => void;
  setDeliveryMethod: (v: string) => void;
  setDeliverySpeed: (v: string) => void;
  setPickupPerson: (v: string) => void;
  setCustomerName: (v: string) => void;
  setCustomerPhone: (v: string) => void;
  setCustomerAddress: (v: string) => void;
  setCustomerCity: (v: string) => void;
  setCustomerPin: (v: string) => void;
  setOrderId: (v: string) => void;
  setCurrentStep: (v: number) => void;
  resetOrder: () => void;
}

const defaultState: OrderState = {
  garment: "",
  color: "Black",
  size: "L",
  artworkUrl: null,
  artworkPosition: { x: 50, y: 30, width: 120, height: 120 },
  printSize: "A4",
  clothingQty: 1,
  designQty: 1,
  deliveryMethod: "",
  deliverySpeed: "normal",
  pickupPerson: "",
  customerName: "",
  customerPhone: "",
  customerAddress: "",
  customerCity: "",
  customerPin: "",
  orderId: null,
  currentStep: 1,
};

export const useOrderStore = create<OrderState & OrderActions>()(
  persist(
    (set) => ({
      ...defaultState,
      setGarment: (v) => set({ garment: v }),
      setColor: (v) => set({ color: v }),
      setSize: (v) => set({ size: v }),
      setArtworkUrl: (v) => set({ artworkUrl: v }),
      setArtworkPosition: (v) => set({ artworkPosition: v }),
      setPrintSize: (v) => set({ printSize: v }),
      setClothingQty: (v) => set({ clothingQty: v }),
      setDesignQty: (v) => set({ designQty: v }),
      setDeliveryMethod: (v) => set({ deliveryMethod: v }),
      setDeliverySpeed: (v) => set({ deliverySpeed: v }),
      setPickupPerson: (v) => set({ pickupPerson: v }),
      setCustomerName: (v) => set({ customerName: v }),
      setCustomerPhone: (v) => set({ customerPhone: v }),
      setCustomerAddress: (v) => set({ customerAddress: v }),
      setCustomerCity: (v) => set({ customerCity: v }),
      setCustomerPin: (v) => set({ customerPin: v }),
      setOrderId: (v) => set({ orderId: v }),
      setCurrentStep: (v) => set({ currentStep: v }),
      resetOrder: () => set(defaultState),
    }),
    { name: "vibeweave-order" }
  )
);
