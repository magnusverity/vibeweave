# VibeWeave — Owner Setup / Final Configuration

The prototype now includes the backend foundations for:

- Customer accounts (signup/login/session/profile)
- Order-to-account linking
- Token wallet + transaction ledger
- Agent records with phone/address fields
- Normal + express delivery selection
- Server-owned delivery fees and ETA configuration
- Manual UPI payment flow
- UPI QR asset at `/payment/upi-qr.png`
- UPI transaction/UTR submission for manual verification
- Admin payment/order/token controls

## Values that MUST be confirmed before production

### 1. Payment recipient
The supplied QR visibly contains a different recipient identity than the payment name/phone supplied separately. Do not assume they belong to the same account.

Set these only after the owner confirms the correct recipient:

```env
VIBEWEAVE_PAYMENT_NAME=
VIBEWEAVE_UPI_ID=
VIBEWEAVE_PAYMENT_PHONE=
```

The QR image is already included and should also be confirmed against the final UPI account.

### 2. Delivery pricing
Replace the placeholder values:

```env
NORMAL_DELIVERY_FEE=0
NORMAL_DELIVERY_ETA_DAYS=5
EXPRESS_DELIVERY_FEE=0
EXPRESS_DELIVERY_ETA_DAYS=2
```

The backend will calculate the final order total from these values; the client cannot override them.

### 3. Token economics
The token wallet/ledger is implemented, but the business rules were not specified. Before launch, define:

- What 1 token is worth
- How users earn tokens
- Whether users can buy tokens
- What tokens can be spent on
- Whether tokens expire
- Refund/cancellation behaviour for token-funded purchases

Do not invent these rules in production.

### 4. Cost of goods / product pricing
The current product prices in `src/lib/constants.ts` are retained from the existing project because no new exact owner-approved price table was supplied in the latest instruction. Replace them with the owner's final values before launch if they differ.

### 5. Colours
The current 12 colour definitions are retained until the owner's exact replacement colour list/hex values are supplied.

### 6. Collection images
The current shop/collection uses the project's existing product image set. If the owner meant a new set of supplied collection images, add those image files and replace the URLs in the product/collection data.

## Database

Run the migrations in `drizzle/` against PostgreSQL. The second migration adds the owner-requested account, token, agent, delivery, and payment fields.

## Security

Set a strong random `ADMIN_API_KEY`. Never commit production secrets to source control.

## Payment verification

Manual UPI payment is intentionally **not auto-marked as paid**. A customer submits the UTR/transaction reference; an admin verifies it and changes payment status to `paid`.


## Payment clarification
The bundled UPI QR is for **Ayaan Khandekar**. The QR image is stored at `public/payment/upi-qr.png`. Keep the displayed recipient identity aligned with the actual UPI account before launch. The UPI ID can be supplied through `VIBEWEAVE_UPI_ID` if the owner wants it shown as text.

## Frontend/backend wiring
The customer Studio now calls the backend pricing endpoint for the displayed checkout total, uses backend delivery options, creates orders through `POST /api/orders`, and loads the manual UPI payment details after order creation. Account details are automatically used to prefill delivery fields when the customer is logged in.
