CREATE TABLE IF NOT EXISTS "orders" (
  "id" text PRIMARY KEY NOT NULL,
  "garment" text NOT NULL,
  "color" text NOT NULL,
  "size" text NOT NULL,
  "artwork_url" text,
  "artwork_position" jsonb,
  "print_size" text NOT NULL,
  "clothing_qty" integer NOT NULL DEFAULT 1,
  "design_qty" integer NOT NULL DEFAULT 1,
  "delivery_method" text NOT NULL,
  "pickup_person" text,
  "customer_name" text,
  "customer_phone" text,
  "customer_address" text,
  "customer_city" text,
  "customer_pin" text,
  "status" text NOT NULL DEFAULT 'payment_pending',
  "payment_status" text NOT NULL DEFAULT 'pending',
  "payment_provider" text,
  "payment_reference" text,
  "total_amount" integer NOT NULL DEFAULT 0,
  "created_at" timestamp NOT NULL DEFAULT now(),
  "updated_at" timestamp NOT NULL DEFAULT now()
);

ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "payment_status" text NOT NULL DEFAULT 'pending';
ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "payment_provider" text;
ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "payment_reference" text;
ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "updated_at" timestamp NOT NULL DEFAULT now();

UPDATE "orders" SET "status" = 'payment_pending' WHERE "status" IN ('pending', 'confirmed');
UPDATE "orders" SET "payment_status" = 'pending' WHERE "payment_status" IS NULL;

CREATE INDEX IF NOT EXISTS "orders_status_idx" ON "orders" ("status");
CREATE INDEX IF NOT EXISTS "orders_payment_status_idx" ON "orders" ("payment_status");
CREATE INDEX IF NOT EXISTS "orders_created_at_idx" ON "orders" ("created_at");
