CREATE TABLE IF NOT EXISTS "accounts" (
  "id" text PRIMARY KEY NOT NULL,
  "email" text NOT NULL,
  "password_hash" text NOT NULL,
  "name" text NOT NULL,
  "phone" text,
  "address" text,
  "city" text,
  "pin" text,
  "token_balance" integer NOT NULL DEFAULT 0,
  "created_at" timestamp NOT NULL DEFAULT now(),
  "updated_at" timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS "accounts_email_unique" ON "accounts" ("email");

CREATE TABLE IF NOT EXISTS "sessions" (
  "id" text PRIMARY KEY NOT NULL,
  "account_id" text NOT NULL REFERENCES "accounts"("id") ON DELETE CASCADE,
  "expires_at" timestamp NOT NULL,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "sessions_account_idx" ON "sessions" ("account_id");

CREATE TABLE IF NOT EXISTS "token_transactions" (
  "id" text PRIMARY KEY NOT NULL,
  "account_id" text NOT NULL REFERENCES "accounts"("id") ON DELETE CASCADE,
  "amount" integer NOT NULL,
  "type" text NOT NULL,
  "reason" text NOT NULL,
  "reference" text,
  "created_at" timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "token_transactions_account_idx" ON "token_transactions" ("account_id");
CREATE INDEX IF NOT EXISTS "token_transactions_created_idx" ON "token_transactions" ("created_at");

CREATE TABLE IF NOT EXISTS "agents" (
  "id" text PRIMARY KEY NOT NULL,
  "name" text NOT NULL,
  "phone" text,
  "address" text,
  "availability" text,
  "active" integer NOT NULL DEFAULT 1,
  "created_at" timestamp NOT NULL DEFAULT now(),
  "updated_at" timestamp NOT NULL DEFAULT now()
);

ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "account_id" text REFERENCES "accounts"("id") ON DELETE SET NULL;
ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "delivery_speed" text;
ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "delivery_fee" integer NOT NULL DEFAULT 0;
ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "delivery_eta_days" integer;
ALTER TABLE "orders" ADD COLUMN IF NOT EXISTS "payment_proof_url" text;
CREATE INDEX IF NOT EXISTS "orders_account_idx" ON "orders" ("account_id");

INSERT INTO "agents" ("id", "name", "availability") VALUES
  ('srijit', 'Srijit', 'Available Mon–Sat'),
  ('ayaan', 'Ayaan', 'Available Mon–Fri')
ON CONFLICT ("id") DO NOTHING;
